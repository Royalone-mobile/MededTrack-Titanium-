//============================================================+
// File name     : app.js for MedEdResidents
// Begin           : Friday; October 30, 2015, 1:02 PM
// Last Update  : Friday; October 30, 2015
//
// Description : MedEdResident App for Residents
//
//
// Author: Marc Schneider
//
// (c) Copyright:
//                      Aultman Health Foundation and
//                      Marc Schneider
//                      Avondale Labs
//                      Canton OH
//============================================================+

// this sets the background color of the master UIView (when there are no windows/tab groups on it)
Titanium.UI.setBackgroundColor('#000');

// Test for connectivity
while (!Titanium.Network.online) {
	var alertDialog = Titanium.UI.createAlertDialog({
		title : 'WARNING!',
		message : 'Your device is not online.  Press Retry or Exit.',
		buttonNames : ['Retry']
	});
	alertDialog.show();
}

// Set Global Vars
var appGlobal = {
	srvcEndPt : "https://admin.mededtrack.com/sep/mobileSrvcEndPt1-1.php",
	imageEndPt : "https://admin.mededtrack.com/sep/imageSrvcEndPt1-0.php",
	httpDomain : "https://admin.mededtrack.com/",
	colorOne : '#003893',
	copyrightText : new Date().getFullYear() + " MedEdTrack LLC - All Right Reserved",
	handHeldCopyrightText : new Date().getFullYear() + " MedEdTrack - All Right Reserved",
	inactivityTimeOut : 45000,
	inactivityTimer : 0,
	logoImagePath : null,
	osName : Ti.Platform.osname,
	osVersion : Ti.Platform.version,
	appVersion : Ti.App.version,
	appName : Ti.App.name,
	prevAppVersion : Ti.App.Properties.getString('prevAppVersion'),
	height : Ti.Platform.displayCaps.platformHeight,
	width : Ti.Platform.displayCaps.platformWidth,
	backButton : false,
	retryTimer : {},
	device : {},
	form : {},
	manual : {},
	settingsShown : false,
	licensetbl : {},
	faculty : {},
	resident : {},
	results : {},
	msCart : {},
	winStack : [],
	tabGroup : {},
	contactUsEmail : 'contactus@mededtrack.com',
	androidBackButton : null,
	dbName : 'metDB',
	db : {},
	currentMilestone : null,
	activationCode : ''
};

appGlobal.wordWrap = false;
appGlobal.ellipsize = false;
if (Ti.Platform.name == 'android') {
	appGlobal.colorOne = 'blue';
	appGlobal.wordWrap = true;
	appGlobal.ellipsize = true;
}

switch (Ti.Platform.model) {
case 'Simulator':
	appGlobal.srvcEndPt = "http://localhost:8080/MedEdTrack-Admin/sep/mobileSrvcEndPt1-1.php";
	appGlobal.imageEndPt = "http://localhost:8080/MedEdTrack-Admin/sep/imageSrvcEndPt1-0.php";
	break;
case 'Android SDK built for x86':
	appGlobal.srvcEndPt = "http://10.0.2.2:8080/MedEdTrack-Admin/sep/mobileSrvcEndPt1-1.php";
	appGlobal.imageEndPt = "http://10.0.2.2:8080/MedEdTrack-Admin/sep/imageSrvcEndPt1-0.php";
	break;
}

// Service End Points
Ti.API.info("Service End Point = " + appGlobal.srvcEndPt);
var Cloud = require('ti.cloud');
rootFunction();

function rootFunction() {

	// Test for connectivity
	while (!Titanium.Network.online) {
		var alertDialog = Titanium.UI.createAlertDialog({
			title : 'WARNING!',
			message : 'Your device is not online.  Press Retry or Exit.',
			buttonNames : ['Retry']
		});
		alertDialog.show();
	}

	Ti.API.info("Getting Device Information for " + Ti.Platform.id);
	var getDeviceID = require('ui/common/commLink');
	getDeviceID({
		request : 'getDeviceData',
		platformID : Ti.Platform.id,
		appName : Ti.App.name
	}, deviceCheckCB);

	function deviceCheckCB(jsonReturn) {
		if ( typeof jsonReturn == 'undefined') {
			alert("Unable retrieve device information.  Check connectivity and try again.");
			return false;
		}
		if (jsonReturn.errorMsg) {
			alert("Error Message" + errorMsg);
			return false;
		}

		Ti.App.Properties.setString('deviceID', jsonReturn.deviceID);
		appGlobal.deviceID = jsonReturn.deviceID;
		appGlobal.idOrgTbl = jsonReturn.idOrgTbl;
		appGlobal.accountVerified = jsonReturn.accountVerified;
		appGlobal.deviceData = jsonReturn;
		Ti.API.info(JSON.stringify(jsonReturn));
		appGlobal.licensetbl.idLicenseTbl = jsonReturn.idLicenseTbl;
		appGlobal.lastChange = jsonReturn.lastChange;
		appGlobal.lastSynch = Ti.App.Properties.getString('lastSynch');
		Ti.API.info("Current App Version = " + appGlobal.appVersion);
		Ti.API.info("Previous App Version = " + appGlobal.prevAppVersion);
		Ti.API.info("Last DB Change = " + appGlobal.lastChange);
		Ti.API.info("Last Synch = " + appGlobal.lastSynch);
		Ti.API.info('Device ID = ' + appGlobal.deviceID);
		Ti.API.info("Org Number = " + appGlobal.idOrgTbl);
		Ti.API.info("License ID = " + appGlobal.licensetbl.idLicenseTbl);
		Ti.API.info("Resident ID = " + appGlobal.deviceData.idResidentTbl);

		var saveDeviceData = require('ui/common/saveDeviceData');
		saveDeviceData();
		Ti.API.info("Platform OS = " + Ti.Platform.name);
		
		if (Ti.Platform.name == 'iOS') {
			apnMod();
		}
		if (Ti.Platform.name == 'android') {
			//gcmMod();
		}

		// on launch
		processArgs();

		var win = Ti.UI.createWindow({
			title : "MedEdResident",
			tabBarHidden : true,
			//backButtonTitle : "Back",
			navBarHidden : true,
			backgroundColor : 'white',
			parentWindow : null
		});

		if (Ti.Platform.name == 'android') {
			var softInput = Ti.UI.Android.SOFT_INPUT_STATE_HIDDEN | Ti.UI.Android.SOFT_INPUT_ADJUST_PAN;
			win.windowSoftInputMode = softInput;
			win.addEventListener('android:back', function(e) {
				e.cancelBubble = true;
				Ti.App.fireEvent(appGlobal.androidBackButton);
			});
		}

		if (Ti.Platform.name == 'iOS') {
			win.transition = Titanium.UI.iOS.AnimationStyle.FLIP_FROM_LEFT;
			//win.statusBarStyle = Titanium.UI.iOS.StatusBar.TRANSLUCENT_BLACK;
		}

		var mainViewMod = require('ui/handheld/mainView');
		mainViewMod(win);

		win.open();

	}

	function urlToObject(url) {

		var returnObj = {};
		url = url.replace('MedEdTrackResident://?', '');
		var params = url.split('&');
		params.forEach(function(param) {
			var keyAndValue = param.split('=');
			returnObj[keyAndValue[0]] = decodeURI(keyAndValue[1]);
		});
		return returnObj;
	}

	function processArgs() {
		Ti.API.info("Platform Name = " + Ti.Platform.name);
		switch (Ti.Platform.name) {
		case 'android':
			var activity = Ti.Android.currentActivity;
			var args = activity.getIntent().getData();
			
			Ti.API.info("Arguments = " + JSON.stringify(args));
			/*
			if (args) {
				var returnObj = urlToObject(args.url);
				Ti.API.info("returnObj = " + JSON.stringify(returnObj));
				if (returnObj['mededtrackfaculty://?activationCode'] != undefined) {
					appGlobal.activationCode = returnObj['mededtrackfaculty://?activationCode'];
					Ti.App.fireEvent('resetActivateView');
				}
			}
			*/
			break;
		case 'iOS':
			var args = Ti.App.getArguments();
			Ti.API.info("Arguments = " + JSON.stringify(args));
			if (args.url != undefined) {
				if (args.url) {
					var returnObj = urlToObject(args.url);
					Ti.API.info("returnObj = " + JSON.stringify(returnObj));
					if (returnObj['mededtrackresident://?activationCode'] != undefined) {
						appGlobal.activationCode = returnObj['mededtrackresident://?activationCode'];
						Ti.App.fireEvent('resetActivateView');
					}
				}
			}
			break;
		}
	}

	// on resume
	Ti.App.addEventListener("resumed", function() {
		Ti.API.info("Resumed");
		Ti.App.fireEvent('restartControlView');
		processArgs();
	});

	// GCMS
	function gcmMod() {
		var CloudPush = require('ti.cloudpush');
		var deviceToken = null;
		CloudPush.retrieveDeviceToken({
		    success: function deviceTokenSuccess(e) {
		        Ti.API.info('Device Token: ' + e.deviceToken);
		        deviceToken = e.deviceToken;
		    },
		    error: function deviceTokenError(e) {
		        alert('Failed to register for push! ' + e.error);
		    }
		});
		/*
		CloudPush.addEventListener('callback', function(evt) {
			alert(evt.payload);
		});
		CloudPush.addEventListener('trayClickLaunchedApp', function(evt) {
			Ti.API.info('Tray Click Launched App (app was not running)');
		});
		CloudPush.addEventListener('trayClickFocusedApp', function(evt) {
			Ti.API.info('Tray Click Focused App (app was already running)');
		});
		CloudPush.retrieveDeviceToken({
			success : deviceTokenSuccess,
			error : deviceTokenError
		});
		*/

	}

	// APNS
	function apnMod() {

		// Register for push notifications iOS
		Ti.API.info("Starting registration for APN");

		var deviceToken = null;

		// Check if the device is running iOS 8 or later
		Ti.API.info("Setting up iOS 8+ APN");
		// Wait for user settings to be registered before registering for push notifications
		Ti.App.iOS.addEventListener('usernotificationsettings', function registerForPush() {

			// Remove event listener once registered for push notifications
			Ti.App.iOS.removeEventListener('usernotificationsettings', registerForPush);

			Ti.Network.registerForPushNotifications({
				success : deviceTokenSuccess,
				error : deviceTokenError,
				callback : apnPush
			});
		});

		// Register notification types to use
		Ti.App.iOS.registerUserNotificationSettings({
			types : [Ti.App.iOS.USER_NOTIFICATION_TYPE_ALERT, Ti.App.iOS.USER_NOTIFICATION_TYPE_SOUND, Ti.App.iOS.USER_NOTIFICATION_TYPE_BADGE]
		});

		// Process incoming push notifications
		function apnPush(e) {
			Ti.API.info("APN = " + JSON.stringify(e));
			var badge = e.data.badge;
			Ti.API.info("APN = " + JSON.stringify(e.data));
			if (badge != undefined) {
				Ti.API.info('Alert Badge Number = ' + badge);
				Ti.UI.iOS.appBadge = parseInt(badge);
			}
			Ti.API.info(JSON.stringify(e));
			if (e.data.sound != 'silent') {
				Titanium.Media.vibrate();
			}
			var soundFile = e.data.sound;
			if (!soundFile || soundFile == 'default') {
				soundFile = 'default.wav';
			}
			//alert(soundFile);
			if (soundFile != 'silent') {
				var player = Ti.Media.createSound({
					url : '/sounds/' + soundFile
				});
				player.play();
			}
		}

	}

	// Save the device token for subsequent API calls
	function deviceTokenSuccess(e) {
		appGlobal.deviceToken = e.deviceToken;
		Ti.API.info('Push Device Token = ' + appGlobal.deviceToken);
		Ti.API.info("Push notification types: " + Titanium.Network.remoteNotificationTypes);
		Ti.API.info("Push notification enabled: " + Titanium.Network.remoteNotificationsEnabled);
		//alert('device token=' + appGlobal.deviceToken);

		var saveAPNToken = require('ui/common/commLink');
		saveAPNToken({
			request : 'saveAPNToken',
			deviceID : appGlobal.deviceID,
			appName : appGlobal.appName,
			deviceToken : appGlobal.deviceToken
		}, saveAPNTokenCB);

		//subscribeToChannel();
	}

	function saveAPNTokenCB(jsonReturn) {
		Ti.API.info("APN Token has been saved.");
	}

	function deviceTokenError(e) {
		Ti.API.info("Error during registration: " + e.error);
		alert('Failed to register for push notifications! ' + e.error);
	}

}

