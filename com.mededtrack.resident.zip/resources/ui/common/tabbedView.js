function standardView(zIdx) {

	var self = Ti.UI.createView({
		height : '100%',
		width : '100%',
		backgroundColor : 'white',
		zIndex : zIdx
	});
	
	
	
	var copywriteText = Ti.UI.createLabel({
		font : {
			fontSize : 10
		},
		bottom : '5dip',
		color : 'black',
		text : appGlobal.handHeldCopyrightText
	});
	

	var versionLabel = Ti.UI.createLabel({
		font : {
			fontSize : 10
		},
		bottom : '5dip',
		left : '5dip',
		color : 'black',
		text : "V " + appGlobal.appVersion
	});

	self.add(versionLabel,copywriteText);

	return self;

}

module.exports = standardView;
