function backView(zIdx,headerImageFile,backFn) {

	var self = Ti.UI.createView({
		height : '100%',
		width : '100%',
		backgroundColor : 'white',
		zIndex : zIdx
	});

	var headerView = Ti.UI.createView({
		backgroundColor : '#ffffff',
		top : '0dp',
		height : '70dp',
		width : '100%',
	});
	
	var backIconGlyph = Ti.UI.createImageView({
		image: '/images/handheld/backIconGlyph.png',
		height : Ti.UI.SIZE,
		left: '1%',
		zIndex: 4
	});
	
	var headerImage = Ti.UI.createImageView({
		image: '/images/handheld/'+headerImageFile,
		left: '1%',
	});

	headerView.add(backIconGlyph);
	headerView.add(headerImage);
	
	self.add(headerView);

	var copywriteText = Ti.UI.createLabel({
		font : {
			fontSize : 10
		},
		bottom : '5dp',
		right : '5dp',
		color : 'black',
		text : appGlobal.handHeldCopyrightText
	});

	var versionLabel = Ti.UI.createLabel({
		font : {
			fontSize : 10
		},
		bottom : '5dp',
		left : '5dp',
		color : 'black',
		text : "V " + appGlobal.appVersion
	});
	
	backIconGlyph.addEventListener('click',backFn);
	
	

	self.add(versionLabel);
	self.add(copywriteText);

	return self;

}

module.exports = backView;
