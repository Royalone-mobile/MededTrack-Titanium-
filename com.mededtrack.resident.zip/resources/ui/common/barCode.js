function barCode () {

	// Bar Code Settings 
	var barcodereader = undefined;
	var barcodeCodeWindow = undefined;
	var barcodeCodeView = undefined;
	
		barcodereader = require('com.acktie.mobile.ios.barcode');
	
	// All supported Barcode types
	var ALL = [
	    "EAN2",
	    "EAN5",
	    "EAN8",
	    "UPCE",
	    "ISBN10",
	    "UPCA",
	    "EAN13",
	    "ISBN13",
	    "COMPOSITE",
	    "I25",
	    "DATABAR",
	    "DATABAR_EXP",
	    "CODE39",
	    "PDF417",
	    "CODE93",
	    "CODE128",];
	
	// Examples of Barcode type groups
	var EAN = [
	    "EAN2",
	    "EAN5",
	    "EAN8",
	    "EAN13"];
	    
	var UPC = [
	    "UPCE",
	    "UPCA",];
	    
	var ISBN13 = [
		"EAN13",
	    "ISBN13",];
	    
	var ISBN10 = [
		"EAN13",
	    "ISBN10",];
	    
	var DATABAR = [
	    "DATABAR",
	    "DATABAR_EXP",];
	
	var CODE = [
	    "CODE39",
	    "CODE93",
	    "CODE128",];
		//create component instance
			
	
	var options = {

		// ** Used by iOS (allowZoom/userControlLight ignored on Android)
		userControlLight : true,
		allowZoom : true,
		// ** Used by both iOS and Android
		barcodes:ALL,
		//continuous : true,
		success : success,
		cancel : cancel,
		error : error
	};

	Ti.API.info('Scanner launched');

	barcodereader.scanBarcodeFromCamera(options);
	
	function success(data) {
	if(data != undefined && data.data != undefined) {
		
		Titanium.Media.vibrate();
		Ti.API.info('Barcode read: ' + data.data);
		
		var player = Ti.Media.createSound();
		
		var unpackedStr = data.data.split('^');
		if (unpackedStr.length > 2){
			appGlobal.form.idCampaignTbl = unpackedStr[1];
			if (!appGlobal.form.idCampaignTbl){
				appGlobal.form.idCampaignTbl = '1';
			}
			
			appGlobal.form.company = unpackedStr[2];
			appGlobal.form.employeeNumber = unpackedStr[3];
			player.url = 'sounds/goodRead.wav';
			Ti.App.fireEvent('displayBarCode',data);
		} else {
			player.url = 'sounds/badRead.wav';
		}
		player.play();
		}
	};
	
	function cancel() {
		Ti.API.info('Scanning canceled');
		//alert("Cancelled");
		setStatus('Scanning cancelled');
	};
	
	function error() {
		Ti.API.info('Scanning error');
		setStatus('Scanning error');
		alert("Scanning Error");
	};
	
	function setStatus(text) {
		var textObj = {text: text};
		
		Ti.API.info(text);
	}
	
}

module.exports = barCode;
