function blankView() {

	var self = Ti.UI.createView({
		height : '100%',
		width : '100%',
		backgroundColor : 'black',
		zIndex : 19
	});


	return self;

};

module.exports = blankView;
