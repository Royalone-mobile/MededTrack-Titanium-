function saveDeviceData() {

	// Save Device and OS Details
	var saveAppDetails = require('ui/common/commLink');
	saveAppDetails({
		request : 'saveAppDetails',
		deviceID : appGlobal.deviceID,
		osName : appGlobal.osName,
		osVersion : appGlobal.osVersion,
		appVersion : appGlobal.appVersion
	}, saveAppDetailsCB);


	function saveAppDetailsCB() {
		// Nothing to do
	}

}

module.exports = saveDeviceData;

