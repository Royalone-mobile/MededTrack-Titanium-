//============================================================+
// File name     : commLink.js
// Begin           : Monday; October 7, 2013, 8:52 AM
// Last Update  : Monday; October 7, 2013
//
// Description : Common HTTP Client
//               
//
// Author: Marc Schneider
//
// (c) Copyright: October 7, 2013
//                      Aultman Health Foundation and
//                      Marc Schneider
//                      Avondale Labs
//                      Canton OH
//============================================================+

function commLink(params,callback) {
	
var xhr = Titanium.Network.createHTTPClient({
	onload: function(e) {
		callback(JSON.parse(this.responseText));
    },
    onerror : function(e) {
         Ti.API.debug(e.error);
         callback(JSON.stringify({ errorMsg: "Error " + e.error}));
     },
     timeout : 8000  // in milliseconds
  	});
	
	xhr.autoEncodeUrl = false;
	xhr.open("POST",appGlobal.srvcEndPt);  
	xhr.send(JSON.stringify(params));
  }
    
module.exports = commLink;
