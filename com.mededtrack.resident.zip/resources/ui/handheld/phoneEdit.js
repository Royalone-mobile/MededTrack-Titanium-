function phoneEdit() {

	var accountVerified = false;

	var selfMod = require('ui/common/backView');

	var self = new selfMod(13, "phone.png", backFn);

	var phoneContainer = Ti.UI.createView({
		backgroundColor : 'white',
		width : '100%',
		height : '80%',
		top : '65dip',
	});

	var phoneView = Ti.UI.createView({
		backgroundColor : 'white',
		width : '90%',
		height : 'auto',
		top : '15dip'
	});

	var phoneLabel = Ti.UI.createLabel({
		top : '0dip',
		font : {
			fontSize : 14,
			fontWeight : 'bold'
		},
		color : 'black',
		visible : true,
		text : "Your Mobile Phone",
		left : '6%'
	});

	var mobilePhone = Ti.UI.createTextField({
		height : "45dip",
		width : "88%",
		left : '6%',
		borderWidth : '2dp',
		borderColor : 'gray',
		borderRadius : 6,
		paddingLeft : '6dp',
		supressReturn : false,
		backgroundColor : 'white',
		color : 'black',
		hintText : "Mobile Phone",
		font : {
			fontSize : 18
		},
		keyboardType : Ti.UI.KEYBOARD_TYPE_PHONE_PAD,
		top : '22dip',
		clearButtonMode : Titanium.UI.INPUT_BUTTONMODE_ALWAYS,
		returnKeyType: Titanium.UI.RETURNKEY_DONE,
		editable: false
	});

	var workPhoneLabel = Ti.UI.createLabel({
		top : '79dip',
		font : {
			fontSize : 14,
			fontWeight : 'bold'
		},
		color : 'black',
		visible : true,
		text : "Your Work Phone",
		left : '6%'
	});

	var workPhone = Ti.UI.createTextField({
		height : "45dip",
		width : "88%",
		left : '6%',
		borderWidth : '2dp',
		borderColor : 'gray',
		borderRadius : 6,
		paddingLeft : '6dp',
		supressReturn : false,
		backgroundColor : 'white',
		color : 'black',
		hintText : "Work Phone",
		font : {
			fontSize : 18
		},
		keyboardType : Ti.UI.KEYBOARD_TYPE_PHONE_PAD,
		top : '102dip',
		clearButtonMode : Titanium.UI.INPUT_BUTTONMODE_ALWAYS,
		returnKeyType: Titanium.UI.RETURNKEY_DONE,
		editable: false
	});

	phoneView.add(phoneLabel);
	phoneView.add(mobilePhone);
	phoneView.add(workPhoneLabel);
	phoneView.add(workPhone);

	phoneContainer.add(phoneView);

	self.add(phoneContainer);

	Ti.App.addEventListener('resetPhoneView', function() {
		mobilePhone.editable = true;
		workPhone.editable = true;
		Ti.API.info("Reseting Phone View");
		self.opacity = 1;
		self.zIndex = 20;
		getDeviceSettings();
	});

	function backFn() {
		mobilePhone.blur();
		workPhone.blur();
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
		saveData();
		self.zIndex = 21;
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function getDeviceSettings() {
		var getDeviceSettings = require('ui/common/commLink');
		getDeviceSettings({
			request : 'getDeviceSettings',
			deviceID : appGlobal.deviceID
		}, getPhoneCB);
	}

	function getPhoneCB(json) {
		if ( typeof json.results == 'undefined') {
			alert("Unable to communicate with host at this time.  Please try again later.");
			return false;
		}
		mobilePhone.value = json.results.mobilePhone;
		workPhone.value = json.results.workPhone;
		mobilePhone.focus();
	}

	function saveData() {
		var saveData = require('ui/common/commLink');
		saveData({
			request : 'savePhone',
			deviceID : appGlobal.deviceID,
			mobilePhone : mobilePhone.value,
			workPhone : workPhone.value
		}, saveDataCB);
	}

	function saveDataCB() {
		// display error message if error encountered while saving
	}
	
	function animateCB(){
		self.zIndex = 12;
	}

	return self;

}

module.exports = phoneEdit;
