function activationView() {
	
	var selfMod = require('ui/common/backView');

	var self = new selfMod(2,"activationCode.png",backFn);

	var updateOn = false;

	var licView = Ti.UI.createView({
		width : '100%',
		height : '100%',
		top : '75dp',
	});

	var codeLabel = Ti.UI.createLabel({
		text : 'Your Activation Code',
		font : {
			fontSize : 18,
			fontWeight : 'bold'
		},
		left : '10%',
		top : '50dp',
		color: 'black'
	});

	var activationCode = Ti.UI.createTextField({
		width : '80%',
		height : '45dp',
		hintText : 'Activation Code',
		keyboardType : Ti.UI.KEYBOARD_TYPE_ASCII,
		top : '75dp',
		borderWidth : '2dp',
		borderRadius : 6,
		borderColor: 'black',
		paddingLeft : '6dp',
		color: 'black',
		font: {fontSize: 16},
		value: '',
		autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE
	});
	
	if (Ti.Platform.name != 'android') {
		activationCode.clearButtonMode = Titanium.UI.INPUT_BUTTONMODE_ALWAYS;
	}

	var validateButton = Ti.UI.createButton({
		width : '60%',
		height : '45dp',
		title : "Validate",
		color : 'white',
		backgroundColor : '#ccc',
		borderRadius : 6,
		bottom : '20%',
		font : {
			fontWeight : 'bold'
		},
		enabled : false
	});

	licView.add(codeLabel);
	licView.add(activationCode);
	licView.add(validateButton);

	self.add(licView);

	activationCode.addEventListener('change', function() {
		var p = activationCode.value.trim();
		if (p.length >= 12) {
			validateButton.enabled = true;
			validateButton.backgroundColor = appGlobal.colorOne;
		} else {
			validateButton.enabled = false;
			validateButton.backgroundColor = '#ccc';
		}
	});

	validateButton.addEventListener('click', function() {
		activationCode.blur();
		Ti.API.info("Validate Button Pressed");
		Ti.App.Properties.setString('activationCode', '');
		Ti.App.Properties.setString('token', '');
		Ti.App.Properties.setString('sid', '');
		var activateApp = require('ui/common/commLink');
		activateApp({
			request : 'activateApp',
			activationCode : activationCode.value,
			appName: appGlobal.appName,
			deviceID : appGlobal.deviceID,
		}, validateCB);
	});

	Ti.App.addEventListener('resetActivation', function() {
		self.zIndex = 31;
		self.opacity = 1;
		self.visible = true;
		activationCode.value = appGlobal.activationCode;
		
		var p = activationCode.value.trim();
		if (p.length >= 12) {
			validateButton.enabled = true;
			validateButton.backgroundColor = appGlobal.colorOne;
		} else {
			activationCode.focus();
		}
		
	});

	function validateCB(jsonReturn) {
		if ( typeof jsonReturn.residenttbl == 'undefined') {
			alert("Unable to get activate information at this time.  Please try again.");
			return false;
		}
		if (jsonReturn.errorMsg) {
			alert(jsonReturn.errorMsg);
			activationCode.focus();
			return false;
		}

		Ti.API.info("Res Info = " + JSON.stringify(jsonReturn.residenttbl));

		Ti.App.Properties.setString('idResidentTbl', jsonReturn.residenttbl.idResidentTbl);

		appGlobal.residenttbl = jsonReturn.residenttbl;
		appGlobal.idOrgTbl = appGlobal.residenttbl.idOrgTbl;
		appGlobal.deviceData.idResidentTbl = appGlobal.residenttbl.idResidentTbl;
		appGlobal.licensetbl = jsonReturn.licensetbl;
		Ti.App.fireEvent('resetUpdate');
		self.animate({
			duration : 800,
			opacity : 0
		}, animateDB);

	}

	function animateDB() {
		self.zIndex = 1;
		//self.opacity = 1;
	}
	
	function backFn() {
		activationCode.blur();
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
		self.zIndex = 21;
		self.animate({duration: 400, opacity: 0}, animateCB);
	}
	
	function animateCB(){
		self.zIndex = 12;
	}

	return self;

};

module.exports = activationView;
