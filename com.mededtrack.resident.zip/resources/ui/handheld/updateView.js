function updateView() {

	var dbAr;
	var db;
	var selfMod = require('ui/common/standardView');

	var self = new selfMod(10);

	var activityIndicator = Ti.UI.createActivityIndicator({
		color : 'gray',
		font : {
			fontFamily : 'Helvetica Neue',
			fontSize : 26,
			fontWeight : 'bold'
		},
		message : 'Updating....',
		style : Ti.UI.ActivityIndicatorStyle.DARK,

		height : Ti.UI.SIZE,
		width : Ti.UI.SIZE
	});

	self.add(activityIndicator);

	Ti.App.addEventListener('resetUpdate', resetUpdate);

	self.addEventListener('click', leaveFn);

	function resetUpdate() {
		Ti.API.info("Running DB Update");
		self.zIndex = 20;
		self.opacity = 1;
		activityIndicator.show();
		loadDB();
	}

	function loadDB() {
		Ti.API.info("loadDB");
		if (appGlobal.licensetbl.idLicenseTbl){
		Ti.API.info("Getting DB Information for " + Ti.Platform.id);
		var getDB = require('ui/common/commLink');
		getDB({
			request : 'getDB',
			idLicenseTbl : appGlobal.licensetbl.idLicenseTbl,
		}, loadDBCB);
		}
	}

	function loadDBCB(jsonReturn) {
		if ( typeof jsonReturn == 'undefined') {
			alert("Unable retrieve database information at this time.  Check connectivity and try again.");
			Ti.App.fireEvent('restartControlView');
			return false;
		}
		if (jsonReturn.errorMsg) {
			alert("Error Message" + errorMsg);
			Ti.App.fireEvent('restartControlView');
			return false;
		}
		Ti.API.info("Got DB Package");
		dbAr = jsonReturn.dbAr;
		Ti.API.info("Length of dbAR = " + dbAr.compAr.length);
		createDB(loadComps);
	}

	function leaveFn() {
		self.zIndex = 21;
		Ti.App.fireEvent("restartControlView");
		self.animate({
			duration : 400,
			opacity : 0
		}, leaveFnCB);
	}

	function leaveFnCB() {
		self.zIndex = 8;
	}
	
	function createDB(callback){
		var db;
		db = Ti.Database.open('metDB');
		db.execute('DROP TABLE IF EXISTS competencytbl');
		db.execute('CREATE TABLE IF NOT EXISTS competencytbl(idCompTbl INTEGER PRIMARY KEY,idSpecialtyTbl INTEGER, idCompetencyTbl INTEGER KEY, displayOrder INTEGER, competencyName TEXT);');
		
		db.execute('DROP TABLE IF EXISTS subcomptbl');
		db.execute('CREATE TABLE IF NOT EXISTS subcomptbl(idSubTbl INTEGER PRIMARY KEY,idSubCompTbl INTEGER KEY,idCompetencyTbl INTEGER, idSpecialtyTbl INTEGER, subName TEXT, subDescription TEXT);');
		
		db.execute('DROP TABLE IF EXISTS milestonetbl');
		db.execute('CREATE TABLE IF NOT EXISTS milestonetbl(idMsTbl INTEGER PRIMARY KEY,idMileStoneTbl INTEGER KEY,idSubCompTbl INTEGER, idSpecialtyTbl INTEGER, msName TEXT, msDescription TEXT, msLevel INTEGER);');
		
		db.execute('DROP TABLE IF EXISTS residenttbl');
		db.execute('CREATE TABLE IF NOT EXISTS residenttbl(idResTbl INTEGER PRIMARY KEY, lastName TEXT, firstName TEXT, idSpecialtyTbl INTEGER, idResidentTbl INTEGER, specialtyName TEXT, email TEXT, mobilePhone TEXT);');
		
		db.close();
		callback();
	}
	

	function loadComps() {
		db = Ti.Database.open('metDB');
		db.execute('DELETE FROM competencytbl');
		for ( k = 0; k < dbAr.compAr.length; k++) {
			db.execute('INSERT INTO competencytbl (idSpecialtyTbl, idCompetencyTbl, competencyName, displayOrder) VALUES (?,?,?,?)',dbAr.compAr[k].idSpecialtyTbl,dbAr.compAr[k].idCompetencyTbl, dbAr.compAr[k].competencyName,dbAr.compAr[k].displayOrder);
		}
		Ti.API.info(k + " Comps loaded");
		db.execute('DELETE FROM subcomptbl');
		for ( k = 0; k < dbAr.subcompAr.length; k++) {
			db.execute('INSERT INTO subcomptbl (idSpecialtyTbl,idSubCompTbl,idCompetencyTbl,subName, subDescription) VALUES (?,?,?,?,?)',dbAr.subcompAr[k].idSpecialtyTbl,dbAr.subcompAr[k].idSubCompTbl,dbAr.subcompAr[k].idCompetencyTbl, dbAr.subcompAr[k].subName,dbAr.subcompAr[k].subDescription);
		}
		Ti.API.info(k + " Sub-Comps loaded");
		db.execute('DELETE FROM milestonetbl');
		for ( k = 0; k < dbAr.msAr.length; k++) {
			db.execute('INSERT INTO milestonetbl (idSpecialtyTbl,idMileStoneTbl,idSubCompTbl,msName, msDescription, msLevel) VALUES (?,?,?,?,?,?)',dbAr.msAr[k].idSpecialtyTbl,dbAr.msAr[k].idMileStoneTbl,dbAr.msAr[k].idSubCompTbl, dbAr.msAr[k].msName, dbAr.msAr[k].msDescription,  dbAr.msAr[k].msLevel);
		}
		Ti.API.info(k + " Milestones loaded");
		db.execute('DELETE FROM residenttbl');
		for ( k = 0; k < dbAr.resAr.length; k++) {
			db.execute('INSERT INTO residenttbl (lastName, firstName, idSpecialtyTbl, idResidentTbl, specialtyName, email, mobilePhone) VALUES (?,?,?,?,?,?,?)', dbAr.resAr[k].lastName, dbAr.resAr[k].firstName,dbAr.resAr[k].idSpecialtyTbl,dbAr.resAr[k].idResidentTbl,dbAr.resAr[k].specialtyName,dbAr.resAr[k].email,dbAr.resAr[k].mobilePhone);
		}
		Ti.API.info(k + " Residents loaded");
		db.close();
		Ti.App.Properties.setString('lastSynch',appGlobal.lastChange);
		Ti.App.Properties.setString('prevAppVersion', appGlobal.appVersion);
		appGlobal.prevAppVersion = appGlobal.appVersion;
		leaveFn();
	}

	return self;

};

module.exports = updateView;
