function headerView(title, callback,buttonCallback,buttonLabelText) {

	var headerView = Ti.UI.createView({
		width : '100%',
		top : 0,
		height : '80dip'
	});

	var windowTitle = Ti.UI.createLabel({
		font : {
			fontSize : 20,
			fontWeight : 'bold'
		},
		top : '24dip',
		text : title,
		color : 'white'
	});
	
	var buttonLabel = Ti.UI.createLabel({
		font : {
			fontSize : 20,
		},
		top : '25dip',
		right: '3dip',
		text : title,
		color : 'white',
		text: 'Add'
	});
	
	if (buttonLabelText){
		buttonLabel.text = buttonLabelText;
	}

	if (callback != null) {
		var backButton = Ti.UI.createImageView({
			left : '3dip',
			top : '22dip',
			image: 'images/handheld/backIcon.png',
			width: '70dip'
		});

		backButton.addEventListener('click', callback);

		headerView.add(backButton);
	}
	headerView.add(windowTitle);
	
	if (buttonCallback != null){
		headerView.add(buttonLabel);
		buttonLabel.addEventListener('click',buttonCallback);
	}
	

	return headerView;
}

module.exports = headerView;
