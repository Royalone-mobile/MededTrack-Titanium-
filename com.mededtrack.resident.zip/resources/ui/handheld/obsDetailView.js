function obsDetailView() {
	
	var selfMod = require('ui/common/backView');

	var self = new selfMod(15,"observationDetail.png",backFn);
	
	var contentView = Ti.UI.createView({
		height: '90%',
		top: '10%',
		width: '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '2%'
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color: 'black'
	});

	var resName = Ti.UI.createLabel({
		top : '18dip',
		left : 0,
		color: 'black'
	});
	
	var facultyLabel = Ti.UI.createLabel({
		text : 'Faculty',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		right : 0,
		top : 0,
		width: '48%',
		textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT,
		color: 'black'
	});

	var facultyName = Ti.UI.createLabel({
		color: 'black',
		top : '18dip',
		width: '48%',
		right : 0,
		textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT
	});

	resContainer.add(resLabel);
	resContainer.add(resName);
	resContainer.add(facultyLabel);
	resContainer.add(facultyName);

	contentView.add(resContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '35%',
		top : '51%'
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			fontColor : 'black'
		},
		top : '0dip',
		color : 'black',
		left : 0,
		text : "Milestones"
	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		top : '18dip',
		bottom : 0,
		borderColor : 'black',
		borderWidth : '1dip',
		touchEnabled : true
	});

	var tableData = [];

	viewContainer.add(tableLabel);
	viewContainer.add(tableView);

	var observeView = Ti.UI.createView({
		height : '35%',
		width : '85%',
		top : '13%'
	});

	var observeLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			
		},
		color : 'black',
		left : 0,
		top : 0,
		color: 'black'
	});
	
	var obsScroll = Ti.UI.createScrollView({
		width: '100%',
		height: 'auto',
		borderColor : 'black',
		borderWidth : '1dp',
		top : '18dp',
	});

	var observation = Ti.UI.createLabel({
		width : '98%',
		color: 'black',
		top: 0
	});
	
	obsScroll.add(observation);

	observeView.add(observeLabel);
	observeView.add(obsScroll);

	contentView.add(viewContainer);
	contentView.add(observeView);
	
	self.add(contentView);

	
	Ti.App.addEventListener('resetObsDetail', function() {
		
		appGlobal.androidBackButton = 'detailBackButton';
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		facultyName.text = appGlobal.obsData.facultyName;
		observeLabel.text = "Observation on "+appGlobal.obsData.obsDateLong;
		observation.text = appGlobal.obsData.observation;
		if (!appGlobal.obsData.subCompID){
			tableView.visible = true;
			tableLabel.text = "Milestones";
			buildTable();
		} else {
			tableView.visible = false;
			tableLabel.text = "General Observation on "+appGlobal.obsData.subName;
		}
		
		self.zIndex = 20;
		self.opacity = 1;
	});
	
	Ti.App.addEventListener('detailBackButton', function(){
		backFn();
	});

	
	function buildTable() {
		tableData = [];
		tableView.setData(tableData);
		for ( i = 0; i < appGlobal.obsData.msAr.length; i++) {
			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '50dip',
				hasChild : false,
				milestonetbl : appGlobal.obsData.msAr[i],
			});

			var rowView = Ti.UI.createView({
				width : '98%',
				height : '100%',
				zIndex : 1,
				touchEnabled : true,
				sourceName : 'rowView',
				rowIndex : i
			});
			var messageLabel = Ti.UI.createLabel({
				left : '3dip',
				width : '100%',
				height : '33dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 12
				},
				color : 'black',
				wordWrap : true,
				ellipsize : true,
				text : appGlobal.obsData.msAr[i].subShort+' '+appGlobal.obsData.msAr[i].msName
			});

			rowView.add(messageLabel);
			tableRow.add(rowView);
			tableData.push(tableRow);
		}
		tableView.setData(tableData);

	}
	
	function backFn(){
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("resetObsView");
		self.animate({duration: 400, opacity: 0}, animateCB);
	}
	
	function animateCB(){
		self.zIndex = 15;
		//self.opacity = 1;
	}


	return self;

};

module.exports = obsDetailView;
