function competencyView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(10,"compentencies.png",backFn);
	
	var contentView = Ti.UI.createView({
		height: '90%',
		top: '10%',
		width: '100%',
		backgroundColor : 'white',
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dp',
		top : '3%',
		backgroundColor : 'white',
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color: 'black'
	});

	var resName = Ti.UI.createLabel({
		font: {fontSize: 16},
		top : '18dp',
		left : 0,
		color: 'black'
	});


	resContainer.add(resLabel);
	resContainer.add(resName);
	
	contentView.add(resContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '75%',
		top : '15%',
		backgroundColor : 'white',
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			fontColor : 'black'
		},
		top : '0dp',
		color : 'black',
		left : 0,
		
	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		height : '90%',
		top : '18dp',
		borderColor : 'black',
		borderWidth : '1dp'
	});

	viewContainer.add(tableLabel);
	viewContainer.add( tableView);
	
	contentView.add(viewContainer);
	self.add(contentView);



	Ti.App.addEventListener('resetCompetencyView', function(){
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.androidBackButton = 'compBackButton';
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		tableLabel.text = appGlobal.currentRes.specialtyName + " Compentency";
		//getCompetenciesFn();
		buildTable();
	});
	
	Ti.App.addEventListener('compBackButton', function(){
		backFn();
	});


	function buildTable() {
		var k = 0;
		tableData = [];
		//tableView.setData(tableData);
		var db = Ti.Database.open('metDB');
		var compRS = db.execute('SELECT idCompetencyTbl, competencyName, idSpecialtyTbl FROM competencytbl ORDER BY displayOrder');
		while (compRS.isValidRow()) {
			var competencyName = compRS.fieldByName('competencyName');
			var idCompetencyTbl = compRS.fieldByName('idCompetencyTbl');
			var idSpecialtyTbl = compRS.fieldByName('idSpecialtyTbl');
		
			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '55dp',
				hasChild : false,
				indexVal : k,
				competencytbl : {
					idCompetencyTbl : idCompetencyTbl,
					competencyName : competencyName,
					idSpecialtyTbl : idSpecialtyTbl
				},
				borderColor : '#ccc',
				borderWidth : '1dp',
				width: '100%'
			});

			var tableGlyph = Ti.UI.createImageView({
				image : '/images/handheld/tableGlyph.png',
				right : '2dp',
				height : '60%',
				width : 'auto'
			});

			var rowView = Ti.UI.createView({
				width : '95%',
				height : '100%',
				left: '3dp',
				zIndex : 1,
				indexVal : k,
				backgroundColor : 'white',

			});
			var messageLabel = Ti.UI.createLabel({
				left : '0',
				width : '96%',
				height : '50dp',
				font : {
					fontWeight : 'Bold',
					fontSize : 14
				},
				color : appGlobal.colorOne,
				wordWrap : appGlobal.wordWrap,
				ellipsize : appGlobal.ellipsize,
				indexVal: k,
				text : competencyName
			});

			rowView.add(messageLabel);
			tableRow.add(rowView);
			tableRow.add(tableGlyph);
			tableData.push(tableRow);
			tableRow.addEventListener('click', function(e) {
				appGlobal.currentComp = e.row.competencytbl;
				self.zIndex = 21;
				Ti.App.fireEvent('resetSubCompView');
				self.animate({
					duration : 400,
					opacity : 0
				}, animateCB);
			});
			k++;
			compRS.next();
		}
		tableView.setData(tableData);
		compRS.close();
	}

	function backFn(){
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("restartControlView");
		self.animate({duration: 400, opacity: 0}, animateCB);
	}
	
	function animateCB(){
		self.zIndex = 10;
		//self.opacity = 1;
	}

	return self;

};

module.exports = competencyView;
