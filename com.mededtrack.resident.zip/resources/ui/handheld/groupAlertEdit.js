function groupAlertEdit(win) {
	
	var groupAlert = {};
	var accountVerified = false;

	var headerViewMod = require('ui/handheld/headerView');
	var headerView = headerViewMod('Group Alerts', backButton);

	win.add(headerView);

	var groupContainer = Ti.UI.createView({
		backgroundColor : 'white',
		width : '100%',
		height : '80%',
		top : '65dip',
	});

	var groupView = Ti.UI.createView({
		backgroundColor : 'white',
		width : '90%',
		height : 'auto',
		top : '15dip'
	});
	
	var table = Ti.UI.createTableView({
		width: '100%',
		height: '100%'
	});
	
	var tableData = [];

	//buildTable();
	

	
	groupContainer.add(table);

	win.add(groupContainer);

	win.addEventListener('close', saveData);


	function backButton() {
		win.close();
	}


	function saveData() {
		var setSubscriptions = require('ui/common/commLink');
		setSubscriptions({request: 'setSubscriptions', accountID: appGlobal.accountID, groupAlert: groupAlert,deviceID: appGlobal.deviceID},saveDataCB);
	}

	function saveDataCB() {
		
		var getSubscriptions = require('ui/common/commLink');
		getSubscriptions({
			request : 'getSubscriptions',
			accountID : appGlobal.accountID,
			deviceID: appGlobal.deviceID,
		}, getSubscriptionsCB);
		
	}
	
	function getSubscriptionsCB(jsonReturn) {
			if ( typeof jsonReturn == 'undefined' || typeof jsonReturn.subscriptionAr == 'undefined') {
				alert("Unable retrieve group alert information.  Check connectivity and try again.");
				return false;
			}
			if (jsonReturn.errorMsg) {
				alert("Error Message" + errorMsg);
				return false;
			}
			appGlobal.subscriptionAr = jsonReturn.subscriptionAr;
		}
	
	function buildTable(){
		var getGroups = require('ui/common/commLink');
		getGroups({request: 'getGroupSubscriptions', idCallCenterTbl: appGlobal.idCallCenterTbl, 
		deviceID: appGlobal.deviceID,
		accountID: appGlobal.accountID}, buildTableCB);
	
	}
	
	function buildTableCB(jsonReturn){
		if ( typeof jsonReturn == 'undefined' || typeof appGlobal.subscriptionAr.length == 'undefined') {
				alert("Unable retrieve group alert information.  Check connectivity and try again.");
				return false;
			}
			if (jsonReturn.errorMsg) {
				alert("Error Message" + errorMsg);
				return false;
			}
			
			groupAlert = jsonReturn.callGroupObj;
			Ti.API.info("Group Alert Tbl = "+JSON.stringify(groupAlert));
			for (j=0;j<groupAlert.length;j++){
				groupAlert[j].subscribed = false;
			}
			
			for (i=0;i<appGlobal.subscriptionAr.length;i++){
				for (j=0;j<groupAlert.length;j++){
					if (groupAlert[j].idCallGroupTbl == appGlobal.subscriptionAr[i].idCallGroupTbl){
						groupAlert[j].subscribed = true;
					}
				}
			}
			
			for (j=0;j<groupAlert.length;j++){
				var rowView = Ti.UI.createView({
					width: '95%',
					height: '50dip'
				});
				var rowLabel = Ti.UI.createLabel({
					text: groupAlert[j].groupName,
					width: '80%',
					left: 0
				});
				
				var subscriptionSwitch = Ti.UI.createSwitch({
					value: groupAlert[j].subscribed,
					index: j,
					right: 0
				});
				
				subscriptionSwitch.addEventListener('change',function(e){
					if (this.value){
						groupAlert[e.source.index].subscribed = true;
					} else 
					groupAlert[e.source.index].subscribed = false;
				});
				
				rowView.add(rowLabel,subscriptionSwitch);
				
				var tableRow = Ti.UI.createTableViewRow({
			
				});
				tableRow.add(rowView);
				tableData.push(tableRow);
			}
			
			table.setData(tableData);
			
	}

}

module.exports = groupAlertEdit;
