function settingsView(win) {

	var data = [];

	var self = Ti.UI.createView({
		backgroundColor : '#ffffff',
		height : '100%',
		width : "87%",
		left: 0,
		zIndex : 19,
		visible: true
	});

	var settingsLabel = Ti.UI.createImageView({
		image : '/images/handheld/menuHH.png',
		top : '21dip',
		width : '85%',
		height : Ti.UI.SIZE,
	});

	var settingsField = Ti.UI.createView({
		backgroundColor : 'white',
		top : '62dip',
		height : '100%'
	});

	var table = Ti.UI.createTableView({
		height : '100%',
		width : '100%',
		left : 0,
		backgroundColor : '#ccc'
	});

	Ti.API.info("Initializing Settings View");	

	settingsField.add(table);

	self.add(settingsLabel);
	self.add(settingsField);
	
	Ti.App.addEventListener('buildSettingsTable',function(){
		settingsField.remove(table);
		buildTable();
		settingsField.add(table);
	});
	
	Ti.App.addEventListener('resetSettings',function(){
		Ti.API.info("Settings Page Opened");
		self.zIndex = 19;
		self.opacity = 1;
		buildTable();
	});

	Ti.App.addEventListener('closeSettings',function(){
		self.zIndex = 19;
		self.opacity = 1;
		Ti.API.info("Settings Page Closed");
	});
	
	return self;
	
	function buildTable(){
		Ti.API.info("Building Settings Table");
		data = [];
		table.setData(data);
		var getDeviceSettings = require('ui/common/commLink');
		getDeviceSettings({request: 'getDeviceSettings', deviceID: appGlobal.deviceID},buildTableCB);
	}
	
	
	function buildTableCB(json) {
		
		var emailVerifyLabel = "Unverified";
		
		if (typeof json.results == 'undefined'){
			alert("Unable to communicate with host at this time.  Please try again later.");
			return false;
		}
		
		Ti.API.info("Results = "+JSON.stringify(json));
		
		if (json.results.accountVerified == '1'){
			emailVerifyLabel = '';
		}
		
		appGlobal.idPhotoTbl = json.results.idPhotoTbl;
		appGlobal.accountVerified = json.results.accountVerified;
		
		var accountSection = Ti.UI.createTableViewSection({
			headerView : tableSectionView("Account Settings"),
			
		});
		accountSection.add(addRow('Email / Name',emailVerifyLabel, true, emailEdit));
		accountSection.add(addRow('Phone', '', true, phoneEdit));
		//accountSection.add(addRow('Photo', '', true, photoEdit));
		accountSection.add(addRow('Activation', '', true, activationView));
		data.push(accountSection);

		/*
		var notificationSection = Ti.UI.createTableViewSection({
			headerView: tableSectionView("Notifications")
		});

		notificationSection.add(addRow('Group Alerts','',true,groupAlerts));
		notificationSection.add(addRow('Calendar','',true,selectCalendar));
		data.push(notificationSection);
		*/
		
		var otherSection = Ti.UI.createTableViewSection({
			headerView: tableSectionView("Other")
		});
		
		otherSection.add(addRow('About this App','',true,thisApp));
		data.push(otherSection);

		table.setData(data);
	}
	
	function tableSectionView(sectionName){
		var ts = Ti.UI.createView({
			width: '100%',
			height: '40dip',
			backgroundColor: '#ccc'
		});
		var sl = Ti.UI.createLabel({
			font : {
				fontSize : 16,
				fontWeight : 'bold'
			},
			text : sectionName,
			left : '5%'
		});
		
		ts.add(sl);
		return ts;
	}

	function addRow(leftLabel, rightLabel, hasChild, trigger) {

		var rowView = Ti.UI.createView({
			width : '88%',
			height : '95%',
			visible : true,
			borderRadius : 3,
			backgroundColor : 'white',
			zIndex : 3,
			left : '5%'
		});

		var rowLeft = Ti.UI.createLabel({
			font : {
				fontSize : 16,
				fontWeight : 'bold'
			},
			text : leftLabel,
			left : '0dip',
			color: 'black'
		});

		var rowRight = Ti.UI.createLabel({
			font : {
				fontSize : 14,
				fontWeight: 'bold'
			},
			color: 'red',
			text : rightLabel,
			right : '15dip'
		});

		var row = Ti.UI.createTableViewRow({
			touchEnabled : false,
			height : '45dip',
			hasChild : false,
			backgroundColor : 'white',
			hasTrigger : trigger
		});
		
		var tableGlyph = Ti.UI.createImageView({
				image : '/images/handheld/tableGlyph.png',
				right : '2dp',
				height : '60%',
				width : 'auto',
				visible: hasChild
			});

		if (trigger) {
			row.addEventListener('click', trigger);
		}

		rowView.add(rowLeft);
		rowView.add(rowRight);
		row.add(rowView);
		row.add(tableGlyph);

		return row;

	}

	function emailEdit() {
		Ti.App.fireEvent('resetEmailView');
	}

	function phoneEdit() {

		Ti.App.fireEvent('resetPhoneView');
	}

	function photoEdit() {
		Ti.App.fireEvent('resetPhotoView');
	}
	
	function activationView() {
		Ti.App.fireEvent('resetActivation');
	}

	function groupAlerts() {
		
	}
	
	function selectCalendar() {
		Ti.App.fireEvent('resetCalendarView');
	}
	
	function thisApp() {
		Ti.App.fireEvent('resetThisAppView');
	}
	
}

module.exports = settingsView;
