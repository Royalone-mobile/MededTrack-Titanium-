function controlView(win) {

	var selfMod = require('ui/common/standardView');

	var rowClickOn = true;

	var menuIcon = Ti.UI.createImageView({
		image : '/images/handheld/menuIcon.png',
		height : Ti.UI.SIZE,
		left : '1%',
		width : '6%'
	});

	var self = new selfMod(9, menuIcon);

	menuIcon.addEventListener('click', showMenu);

	var resView = Ti.UI.createView({
		width : '100%',
		height : '75%',
		top : '16%',
		backgroundColor : 'white',
	});

	var resLabel = Ti.UI.createLabel({
		width : '100%',
		font : {
			fontSize : 20,
			
			fontWeight : 'bold'
		},
		textAlignment : 'left',
		top : '0',
		left : '7%',
		color: 'black'
	});

	var resObs = Ti.UI.createLabel({
		width : '100%',
		font : {
			fontSize : 16,
			fontColor : 'black',
			fontWeight : 'bold'
		},
		textAlignment : 'left',
		top : '40dp',
		left : '7%',
		text : 'Observations',
		color: 'black'
	});
	
	var newObs = Ti.UI.createButton({
		title : "New Observations",
		width : '70%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top : '65dp',
	});

	var myObs = Ti.UI.createButton({
		width : '70%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top : '125dp',
		title : 'My Observations'
	});

	var resMS = Ti.UI.createLabel({
		width : '100%',
		font : {
			fontSize : 16,
			fontColor : 'black',
			fontWeight : 'bold'
		},
		textAlignment : 'left',
		top : '195dp',
		left : '7%',
		text : 'Milestones',
		color: 'black'
	});

	var myMS = Ti.UI.createButton({
		width : '70%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top : '220dp',
		title : 'My Milestones'
	});
	
	
	var reportMS = Ti.UI.createButton({
		width : '70%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top : '280dp',
		title : 'Milestone Viewer'
	});
	
	
	var pdfMS = Ti.UI.createButton({
		width : '70%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top : '340dp',
		title : 'Milestone PDF Report',
		visible: false,
		enabled: false
	});

	resView.add(resLabel);
	resView.add(resObs);
	resView.add(myObs);
	resView.add(resMS);
	resView.add(myMS);
	resView.add(newObs);
	resView.add(reportMS);
	/*
	resView.add(pdfMS);
	if (Ti.Platform.name == 'iOS') {
		pdfMS.enabled = true;
		pdfMS.visible = true;
	}
	*/

	self.add(resView);
	
	Ti.App.addEventListener('controlBackButton', function() {
		win.close();
	});

	Ti.App.addEventListener('restartControlView', function() {
		self.opacity = 1;
		self.zIndex = 21;
		fillDisplay();
		appGlobal.androidBackButton = 'controlBackButton';
	});
	
	resLabel.addEventListener('longpress', function(){
		Ti.App.fireEvent("resetUpdate");
		self.zIndex = 9;
		self.opacity = 0;
	});
	
	newObs.addEventListener('click', function() {
		self.zIndex = 30;
		appGlobal.obsFilter = 'New';
		Ti.App.fireEvent("resetObsView",{backEvent: 'restartControlView'});
		self.animate({
			duration : 500,
			opacity : 0
		}, animationCB);
	});
	
	myObs.addEventListener('click', function() {
		self.zIndex = 30;
		appGlobal.obsFilter = 'All';
		Ti.App.fireEvent("resetObsView",{backEvent: 'restartControlView', filter: 'all'});
		self.animate({
			duration : 500,
			opacity : 0
		}, animationCB);
	});

	myMS.addEventListener('click', function() {
		self.zIndex = 30;
		Ti.App.fireEvent("resetCompetencyView",{backEvent: 'resetControlView'});
		self.animate({
			duration : 500,
			opacity : 0
		}, animationCB);
	});
	
	
	reportMS.addEventListener("click", function() {
		self.zIndex = 30;
		Ti.App.fireEvent("resetReportView");
		self.animate({duration: 500, opacity: 0}, animationCB);
		
	});

	
	pdfMS.addEventListener("click", function() {
		self.zIndex = 30;
		Ti.App.fireEvent("resetPDFView");
		self.animate({duration: 500, opacity: 0}, animationCB);
		
	});


	return self;

	function animationCB() {
		self.zIndex = 9;
		//self.opacity = 1;
	}

	function fillDisplay() {
		var getResident = require('ui/common/commLink');
		getResident({
			request : 'getResident',
			idResidentTbl : appGlobal.deviceData.idResidentTbl,
			deviceID: appGlobal.deviceID
		}, getResInfoCB);

	}

	function getResInfoCB(jsonReturn) {
		if ( typeof jsonReturn.residenttbl == 'undefined') {
			alert("Please check your network connectivity.  Unable to retrieve resident information at this time.");
			return false;
		}
		Ti.API.info("jsonReturn ="+JSON.stringify(jsonReturn));
		appGlobal.residenttbl = jsonReturn.residenttbl;
		appGlobal.currentRes = appGlobal.residenttbl;
		resLabel.text = appGlobal.residenttbl.firstName + " " + appGlobal.residenttbl.lastName;
		
		appGlobal.lastSynch = Ti.App.Properties.getString('lastSynch');
		if (appGlobal.lastSynch < appGlobal.lastChange || appGlobal.lastSynch == null || appGlobal.prevAppVersion < appGlobal.appVersion) {
			Ti.App.fireEvent('resetUpdate');
		} else {
			getUnread();
		}
	}
	
	function getUnread(){	
		var getUnread = require('ui/common/commLink');
		getUnread({
			request : 'getUnread',
			deviceID: appGlobal.deviceID,
			idResidentTbl : appGlobal.deviceData.idResidentTbl
		}, getUnreadCB);
	}
	
	function getUnreadCB(jsonReturn){
		if ( typeof jsonReturn == 'undefined') {
			alert("Please check your network connectivity.  Unable to retrieve resident observation data information at this time.");
		}
		var unread = jsonReturn.unread;
		if (unread == '0'){
			newObs.enabled = false;
			newObs.title = 'No New Observations';
			if (Ti.Platform.name == 'iOS') {
				Titanium.UI.iOS.appBadge = 0;
			}
		} else {
			Ti.API.info('Alert Badge Number = ' + unread);
			newObs.title = unread+" New Observations";
			newObs.enabled = true;
			if (Ti.Platform.name == 'iOS') {
				Titanium.UI.iOS.appBadge = parseInt(unread);
			}
		}
	}

	function showMenu() {

		if (!appGlobal.settingsShown) {
			Ti.App.fireEvent('resetSettings');
			appGlobal.settingsShown = true;
			self.animate({
				left : '87%',
				duration : 400,
				opacity : 1
			}, animateCB);

		} else {
			appGlobal.settingsShown = false;
			self.animate({
				left : 0,
				duration : 400,
				opacity : 1
			}, animateCB);
			Ti.App.fireEvent('closeSettings');

		}

		//Ti.App.fireEvent('buildSettingsTable');
	}

	function animateCB() {
		/*
		 if (appGlobal.settingsShown){
		 self.zIndex = 19;
		 } else {
		 self.zIndex = 20;
		 }
		 */
	}

}

module.exports = controlView;
