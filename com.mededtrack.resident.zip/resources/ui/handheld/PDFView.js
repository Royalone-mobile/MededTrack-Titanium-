function PDFView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(11, "residentReport.png", backFn);
	var appFile;
	switch (Ti.Platform.name){
		case 'android':
			appFile = Ti.Filesystem.getFile(Ti.Filesystem.externalStorageDirectory+'ResidentAchievement.pdf');
		break;
		case 'iOS':
			appFile = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory + 'ResidentAchievement.pdf');
			var docViewer = Ti.UI.iOS.createDocumentViewer({});
	
			docViewer.addEventListener('unload', function() {
				docViewer.hide();
				backFn();
			});
		break;
	}

	Ti.App.addEventListener('resetPDFView', function() {
		Ti.App.fireEvent('setLandscape');
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.androidBackButton = 'pdfBackButton';
		if (appGlobal.currentRes) {
			var rptLevel = '1';
			var resAr = [];
			resAr[0] = appGlobal.currentRes.idResidentTbl;
			var resList = encodeURIComponent(JSON.stringify(resAr));
			Ti.API.info("ResList = " + resList);
			var resUrl = 'https://admin.mededtrack.com/residentAchPDF.php?resList=' + resList + '&reportLevel=' + rptLevel;
			Ti.API.info("URL = " + resUrl);

			var appfilepath = appFile.nativePath;
			var xhr = Ti.Network.createHTTPClient();
			xhr.onload = function() {
				appFile.write(this.responseData);
				switch(Ti.Platform.name) {
				case 'android':
					try {
						Ti.Android.currentActivity.startActivity(Ti.Android.createIntent({
							action : Ti.Android.ACTION_VIEW,
							type : 'application/pdf',
							data : appfilepath
						}));
					} catch(e) {
						Ti.API.info('error trying to launch activity, e = ' + e);
						alert('No PDF apps installed!');
					}
					break;
				case 'iOS':
					docViewer.url = appfilepath;
					docViewer.show();
					break;
				}

			};
			xhr.onerror = function() {
				alert("Cannot retrieve PDF from web site");
			};
			xhr.timeout = 10000;
			xhr.open("GET", resUrl);
			xhr.send();

		}
	});

	Ti.App.addEventListener('pdfBackButton', function() {
		Ti.API.info("pdfBackButton");
		backFn();
	});

	function animateCB() {
		self.zIndex = 11;
		//self.opacity = 1;
	}

	function backFn() {
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent('setPortrait');
		Ti.App.fireEvent("restartControlView");
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	return self;

};

module.exports = PDFView;
