function mainView(win) {

	var activationViewMod = require('ui/handheld/activationView');
	var activationView = new activationViewMod();
	
	var activateViewMod = require('ui/handheld/activateView');
	var activateView = new activateViewMod();

	win.add(activateView);
	win.add(activationView);

	var controlViewMod = require("ui/handheld/controlView");
	var controlView = new controlViewMod(win);

	win.add(controlView);

	var compViewMod = require("ui/handheld/competencyView");
	var compView = new compViewMod();

	win.add(compView);

	var subCompViewMod = require("ui/handheld/subCompView");
	var subCompView = new subCompViewMod();

	win.add(subCompView);

	var milestoneViewMod = require("ui/handheld/milestoneView");
	var milestoneView = new milestoneViewMod();

	win.add(milestoneView);
	
	var settingsViewMod = require('ui/handheld/settingsView');
	var settingsView = settingsViewMod(win);
	
	var thisAppMod = require('ui/handheld/thisApp');
	var thisAppView = thisAppMod();
	
	var emailViewMod = require('ui/handheld/emailEdit');
	var emailView = emailViewMod();
	
	var phoneViewMod = require('ui/handheld/phoneEdit');
	var phoneView = phoneViewMod();
	
	var photoViewMod = require('ui/handheld/photoView');
	var photoView = photoViewMod();
	
	var obsViewMod = require('ui/handheld/obsView');
	var obsView = obsViewMod();
	
	var obsDetailViewMod = require("ui/handheld/obsDetailView");
	var obsDetailView = obsDetailViewMod();
	
	var updateViewMod = require("ui/handheld/updateView");
	var updateView = updateViewMod();
	
	var rptViewMod = require("ui/handheld/reportView");
	var rptView = rptViewMod();
	
	var pdfViewMod = require("ui/handheld/PDFView");
	var pdfView = pdfViewMod();

	win.add(settingsView);
	win.add(thisAppView);
	win.add(emailView);
	win.add(phoneView);
	win.add(photoView);
	win.add(obsView);
	win.add(obsDetailView);
	win.add(updateView);
	win.add(rptView);
	win.add(pdfView);

	if (!appGlobal.deviceData.activated || !appGlobal.idOrgTbl) {
		Ti.App.fireEvent('resetActivateView');
	} else {

		if (appGlobal.lastSynch < appGlobal.lastChange || appGlobal.lastSynch == null) {
			Ti.App.fireEvent('resetUpdate');
		} else {
			Ti.App.fireEvent('restartControlView');
		}
	}
	
	if (Ti.Platform.name == 'android') {
		Ti.UI.Android.hideSoftKeyboard();
	}

}

module.exports = mainView;
