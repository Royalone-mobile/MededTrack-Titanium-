function thisApp() {
	
	var selfMod = require('ui/common/backView');

	var self = new selfMod(10,"aboutThis.png",backFn);

	var aboutContainer = Ti.UI.createView({
		backgroundColor : 'white',
		width : '100%',
		height : '80%',
		top : '65dip',
	});

	var aboutView = Ti.UI.createWebView({
		width : '94%',
		height : '100%',
		//borderColor: '#5a5a5a',
		//borderWidth: '1dp',
		url: appGlobal.httpDomain+'/phone/aboutthis.html',
		scalesPageToFit: true
	});
	
	
	var contactButton = Ti.UI.createButton({
		width : '85%',
		height : '35dip',
		color : 'blue',
		bottom : '25dip',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		title : 'Contact Us',
		backgroundColor : 'white',
		enabled : true
	});

	aboutContainer.add(aboutView);

	self.add(aboutContainer);
	self.add(contactButton);
	
	aboutView.addEventListener('doubletap', function(){
		aboutView.reload();
		Ti.API.info("Reload Web Page");
	});
	
	contactButton.addEventListener("click", function() {
		Ti.API.info("Contact Button Click");
		Titanium.Platform.openURL('mailto:' + appGlobal.contactUsEmail);
	});
	
	Ti.App.addEventListener('resetThisAppView', function(){
		Ti.API.info("Reseting This App View");
		self.opacity = 1;
		self.zIndex = 20;
	});

	function backFn() {
		self.zindex = 21;
		self.animate({duration: 400, opacity: 0}, animateCB);
	}
	
	function animateCB(){
		self.zIndex = 12;
	}

	return self;
	
}

module.exports = thisApp;
