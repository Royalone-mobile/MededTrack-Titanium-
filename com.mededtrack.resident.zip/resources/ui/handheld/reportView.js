function reportView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(11,"residentReport.png",backFn);
	
	var contentView = Ti.UI.createWebView({
		height: '90%',
		top: '10%',
		width: '100%',
		url: 'https://admin.mededtrack.com/residentAch.php'
	});
	
	self.add(contentView);

	function animateCB() {
		self.zIndex = 11;
		contentView.url = 'https://admin.mededtrack.com/residentAch.php';
		self.opacity = 1;
	}


	Ti.App.addEventListener('resetReportView', function() {
		//Ti.App.fireEvent('setLandscape');
		Ti.API.info("Reset Report View");
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.androidBackButton = 'rptBackButton';
		
		if (appGlobal.currentRes) {
			contentView.url = 'https://admin.mededtrack.com/residentAch.php?idResidentTbl='+appGlobal.currentRes.idResidentTbl+'&nobackButton=Y&deviceID='+appGlobal.deviceID;
			Ti.API.info("Getting Url = "+contentView.url);
		}
	});
	
	Ti.App.addEventListener('rptBackButton', function(){
		Ti.API.info("Back Button Pressed");
		backFn();
	});

	
	function backFn(){
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		//Ti.App.fireEvent('setPortrait');
		Ti.App.fireEvent("restartControlView");
		self.animate({duration: 400, opacity: 0}, animateCB);
	}
	
	return self;

};

module.exports = reportView;
