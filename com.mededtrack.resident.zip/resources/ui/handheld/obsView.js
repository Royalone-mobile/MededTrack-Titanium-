function obsView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(14, "observationHistory.png", backFn);

	var contentView = Ti.UI.createView({
		height : '90%',
		top : '10%',
		width : '100%',
		backgroundColor : 'white',
	});

	var obsContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '3%'
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color : 'black'
	});

	var resName = Ti.UI.createLabel({
		top : '18dip',
		left : 0,
		color : 'black'
	});

	var obsLabel = Ti.UI.createLabel({
		text : 'Filter',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		right : 0,
		top : 0,
		color : 'black'
	});

	var obsType = Ti.UI.createLabel({
		top : '18dip',
		right : 0,
		color : 'black'
	});

	obsContainer.add(resLabel);
	obsContainer.add(resName);
	obsContainer.add(obsLabel);
	obsContainer.add(obsType);

	contentView.add(obsContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '75%',
		top : '15%',
		backgroundColor : 'white',
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		top : '0dip',
		color : 'black',
		left : 0,
		text : "Observation History"
	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		height : '90%',
		top : '18dip',
		borderColor : 'black',
		borderWidth : '1dip'
	});

	viewContainer.add(tableLabel);
	viewContainer.add(tableView);

	contentView.add(viewContainer);

	var activityIndicator = Ti.UI.createActivityIndicator({
		color : 'gray',
		font : {
			fontFamily : 'Helvetica Neue',
			fontSize : 26,
			fontWeight : 'bold'
		},
		message : 'Loading....',
		style : Ti.UI.ActivityIndicatorStyle.DARK,

		height : Ti.UI.SIZE,
		width : Ti.UI.SIZE,
		visible : true
	});

	var blocking = Ti.UI.createView({
		width : '80%',
		height : '75%',
		zIndex : 10,
		backgroundColor : 'white',
		borderColor : 'gray',
		borderRadius : 10,
		borderWidth : '3dp',

	});

	blocking.add(activityIndicator);

	self.add(blocking);

	self.add(contentView);

	Ti.App.addEventListener('resetObsView', function(e) {
		tableData = [];
		tableView.setData(tableData);
		self.zIndex = 20;
		self.opacity = 1;
		obsType.text = appGlobal.obsFilter;
		appGlobal.androidBackButton = 'obsBackButton';
		getObsFn();
	});

	Ti.App.addEventListener('obsBackButton', function() {
		backFn();
	});

	function getObsFn() {
		blocking.show();
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		var getObs = require('ui/common/commLink');
		var idMileStoneTbl = null;
		if (appGlobal.currentMilestone != null) {
			idMileStoneTbl = appGlobal.currentMilestone.idMileStoneTbl;
		}

		getObs({
			request : 'getObs',
			deviceID : appGlobal.deviceID,
			type : appGlobal.obsFilter,
			idMileStoneTbl : idMileStoneTbl,
			idResidentTbl : appGlobal.currentRes.idResidentTbl
		}, getObsCB);
	}

	function getObsCB(jsonReturn) {
		if ( typeof jsonReturn.obsAr == 'undefined') {
			blocking.hide();
			alert("Unable to communicate with service at this time.  Please try again later.");
			return false;
		}
		appGlobal.obsAr = jsonReturn.obsAr;
		Ti.API.info('Obs Ar = ' + JSON.stringify(appGlobal.obsAr));

		buildTable();
	}

	function buildTable() {

		for ( k = 0; k < appGlobal.obsAr.length; k++) {
			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '55dip',
				hasChild : false,
				obsdatatbl : appGlobal.obsAr[k],
				borderColor : appGlobal.colorOne,
				borderWidth : '1dip'
			});

			var rowView = Ti.UI.createView({
				width : '90%',
				height : '100%',
				left : '0dp',
				zIndex : 1,
				backgroundColor : 'white',
			});
			var messageLabel = Ti.UI.createLabel({
				left : '3dip',
				width : '85%',
				height : '50dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 16
				},
				color : appGlobal.colorOne,
				wordWrap : true,
				ellipsize : true,
				text : appGlobal.obsAr[k].obsDescription
			});

			labelRight = Ti.UI.createLabel({
				right : '0dip',
				width : '12%',
				height : '50dip',
				font : {
					fontSize : 10
				},
				wordWrap : false,
				ellipsize : true,

			});

			var tableGlyph = Ti.UI.createImageView({
				image : '/images/handheld/tableGlyph.png',
				right : '2dp',
				height : '60%',
				width : 'auto',
			});

			if (appGlobal.obsAr[k].noMs > 0) {
				labelRight.color = 'black';
				labelRight.text = appGlobal.obsAr[k].noMs + " MS";
			} else {
				labelRight.color = 'black';
				labelRight.text = "GO";
			}

			rowView.add(messageLabel);
			rowView.add(labelRight);
			tableRow.add(tableGlyph);
			tableRow.add(rowView);
			tableData.push(tableRow);
			tableRow.addEventListener('click', function(e) {
				appGlobal.obsData = e.row.obsdatatbl;
				self.zIndex = 21;
				Ti.App.fireEvent('resetObsDetail');
				self.animate({
					duration : 400,
					opacity : 0
				}, animateCB);
				var setAsRead = require('ui/common/commLink');
				setAsRead({
					request : 'setAsRead',
					deviceID : appGlobal.deviceID,
					idObserveTbl : appGlobal.obsData.idObserveTbl
				}, setAsReadCB);
			});

		}
		tableView.setData(tableData);
		blocking.hide();
	}

	function setAsReadCB(jsonReturn) {
		if ( typeof jsonReturn.unread == 'undefined') {
			return false;
		}
		var unread = jsonReturn.unread;
		if (Ti.Platform.name == 'iOS') {
			if (unread == '0') {
				Titanium.UI.iOS.appBadge = 0;
			} else {
				Titanium.UI.iOS.appBadge = parseInt(unread);
			}
		}
	}

	function backFn() {
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		if (appGlobal.obsFilter == 'Milestone') {
			Ti.App.fireEvent("resetMSView");
		} else {
			Ti.App.fireEvent("restartControlView");
		}
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 14;
		//self.opacity = 1;
	}

	return self;

};

module.exports = obsView;
