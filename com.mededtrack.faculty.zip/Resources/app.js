//============================================================+
// File name     : app.js for MedEdFaculty
// Begin           : Friday; July 17, 2015, 1:02 PM
// Last Update  : Friday; July 17, 2015
//
// Description : MedEdFaculty App for Faculty
//
//
// Author: Marc Schneider
//
// (c) Copyright: July 17, 2015
//                      Aultman Health Foundation and
//                      Marc Schneider
//                      Avondale Labs
//                      Canton OH
//============================================================+

// this sets the background color of the master UIView (when there are no windows/tab groups on it)
Titanium.UI.setBackgroundColor('#000');

// Test for connectivity
while (!Titanium.Network.online) {
	var alertDialog = Titanium.UI.createAlertDialog({
		title : 'WARNING!',
		message : 'Your device is not online.  Press Retry or Exit.',
		buttonNames : ['Retry']
	});
	alertDialog.show();
}

// Set Global Vars
var appGlobal = {
	srvcEndPt : "https://admin.mededtrack.com/sep/mobileSrvcEndPt1-1.php",
	imageEndPt : "https://admin.mededtrack.com/sep/imageSrvcEndPt1-0.php",
	httpDomain : "https://admin.mededtrack.com/",
	colorOne : '#003893',
	copyrightText : new Date().getFullYear() + " MedEdTrack LLC - All Right Reserved",
	handHeldCopyrightText : new Date().getFullYear() + " MedEdTrack - All Right Reserved",
	inactivityTimeOut : 45000,
	inactivityTimer : 0,
	logoImagePath : null,
	osName : Ti.Platform.osname,
	osVersion : Ti.Platform.version,
	appVersion : Ti.App.version,
	prevAppVersion : Ti.App.Properties.getString('prevAppVersion'),
	height : Ti.Platform.displayCaps.platformHeight,
	width : Ti.Platform.displayCaps.platformWidth,
	backButton : false,
	retryTimer : {},
	device : {},
	form : {},
	manual : {},
	settingsShown : false,
	licensetbl : {},
	faculty : {},
	resident : {},
	results : {},
	msCart : {},
	winStack : [],
	tabGroup : {},
	playSound : false,
	returnTo : 'resetCompView',
	contactUsEmail : 'contactus@mededtrack.com',
	androidBackButton : null,
	dbName : 'metDB',
	db : {},
	activationCode: ''
};

if (Ti.Platform.name == 'android') {
	appGlobal.colorOne = 'blue';
}

appGlobal.msCart.msAr = [];
appGlobal.msCart.filed = false;
appGlobal.msCart.observation = '';

appGlobal.msCart.msCartButton = Ti.UI.createButton({
	borderColor : 'purple',
	borderRadius : '4',
	borderWidth : '2dip',
	backgroundColor : 'white',
	color : 'purple',
	right : '0',
	top : '0dip',
	height : '40dip',
	width : '40dip',
	font : {
		fontWeight : 'bold'
	}
});

switch (Ti.Platform.model) {

case 'Simulator':
	appGlobal.srvcEndPt = "http://localhost:8080/MedEdTrack-Admin/sep/mobileSrvcEndPt1-1.php";
	appGlobal.imageEndPt = "http://localhost:8080/MedEdTrack-Admin/sep/imageSrvcEndPt1-0.php";
	break;
case 'Android SDK built for x86':
	appGlobal.srvcEndPt = "http://10.0.2.2:8080/MedEdTrack-Admin/sep/mobileSrvcEndPt1-1.php";
	appGlobal.imageEndPt = "http://10.0.2.2:8080/MedEdTrack-Admin/sep/imageSrvcEndPt1-0.php";
	break;

}

// Service End Points
Ti.API.info("Service End Point = " + appGlobal.srvcEndPt);

rootFunction();

function rootFunction() {

	// Test for connectivity
	while (!Titanium.Network.online) {
		var alertDialog = Titanium.UI.createAlertDialog({
			title : 'WARNING!',
			message : 'Your device is not online.  Press Retry or Exit.',
			buttonNames : ['Retry']
		});
		alertDialog.show();
	}

	Ti.API.info("Getting Device Information for " + Ti.Platform.id);
	var getDeviceID = require('ui/common/commLink');
	getDeviceID({
		request : 'getDeviceData',
		platformID : Ti.Platform.id,
		appName : Ti.App.name
	}, deviceCheckCB);

	// on resume
	Ti.App.addEventListener("resumed", function() {
		Ti.API.info("Resumed");
		Ti.App.fireEvent('restartControlView');
		processArgs();
	});

	function deviceCheckCB(jsonReturn) {
		if ( typeof jsonReturn == 'undefined') {
			alert("Unable to retrieve device information.  Check connectivity and try again.");
			return false;
		}
		if (jsonReturn.errorMsg) {
			alert("Error Message" + errorMsg);
			return false;
		}

		Ti.App.Properties.setString('deviceID', jsonReturn.deviceID);
		appGlobal.deviceID = jsonReturn.deviceID;
		appGlobal.idOrgTbl = jsonReturn.idOrgTbl;
		appGlobal.accountVerified = jsonReturn.accountVerified;
		appGlobal.idFacultyTbl = jsonReturn.idFacultyTbl;
		appGlobal.deviceData = jsonReturn;
		Ti.API.info(JSON.stringify(jsonReturn));
		Ti.API.info("Current App Version = " + appGlobal.appVersion);
		Ti.API.info("Previous App Version = " + appGlobal.prevAppVersion);
		Ti.API.info('Device ID = ' + appGlobal.deviceID);
		Ti.API.info("Org Number = " + appGlobal.idOrgTbl);
		Ti.API.info("Faculty ID = " + appGlobal.idFacultyTbl);
		
		if (jsonReturn.setLicenseNumber == '1'){
			Ti.App.Properties.setString('licenseNumber',jsonReturn.licenseNumber);
		}

		// Set last licenseNumber
		appGlobal.licenseNumber = Ti.App.Properties.getString('licenseNumber');

		Ti.API.info("License Number = " + appGlobal.licenseNumber);

		Titanium.Geolocation.accuracy = Titanium.Geolocation.ACCURACY_HUNDRED_METERS;
		Titanium.Geolocation.distanceFilter = 200;

		var saveAppDetails = require('ui/common/commLink');
		saveAppDetails({
			request : 'saveAppDetails',
			deviceID : appGlobal.deviceID,
			osName : appGlobal.osName,
			osVersion : appGlobal.osVersion,
			appVersion : appGlobal.appVersion
		}, saveAppDetailsCB);


		var licCheck = require('ui/common/commLink');
		licCheck({
			request : 'licCheck',
			licenseNumber : appGlobal.licenseNumber,
			deviceID : appGlobal.deviceID
		}, licCheckCB);

	}
	
	function saveAppDetailsCB() {
		Ti.API.info("App Details Saved");
	}

	function urlToObject(url) {

		var returnObj = {};
		url = url.replace('MedEdTrackResident://?', '');
		var params = url.split('&');
		params.forEach(function(param) {
			var keyAndValue = param.split('=');
			returnObj[keyAndValue[0]] = decodeURI(keyAndValue[1]);
		});
		return returnObj;
	}

	function processArgs() {
		Ti.API.info("Platform Name = " + Ti.Platform.name);
		switch (Ti.Platform.name) {
		case 'android':
			var activity = Ti.Android.currentActivity;
			var args = activity.getIntent().getData();
			Ti.API.info("Android Intent = "+JSON.stringify(args));
			Ti.Android.currentActivity.addEventListener('onIntent', function(e) {
				// code here is run when the event is fired
				// properties of the event object 'e' describe the event and object that received it
				Ti.API.info('The ' + e.intent + ' event happened');
				var intentObj = e.intent;
				var stringItem = intentObj.getStringExtra("android.intent.extra.TEXT");
			});
			break;
		case 'iOS':
			var args = Ti.App.getArguments();
			Ti.API.info("Arguments = " + JSON.stringify(args));
			if (args.url != undefined) {
				if (args.url) {
					var returnObj = urlToObject(args.url);
					Ti.API.info("returnObj = " + JSON.stringify(returnObj));
					if (returnObj['mededtrackfaculty://?activationCode'] != undefined) {
						appGlobal.activationCode = returnObj['mededtrackfaculty://?activationCode'];
						Ti.API.info("Reset Activation");
						Ti.App.fireEvent('resetActivateView');
					}
				}
			}
			break;
		}
	}

	function licCheckCB(jsonReturn) {
		if ( typeof jsonReturn == undefined || jsonReturn.licensetbl == undefined) {
			alert("Unable retrieve license information.  Check connectivity and try again.");
			return false;
		}
		if (jsonReturn.errorMsg) {
			alert("Error Message" + errorMsg);
			return false;
		}
		appGlobal.lastChange = jsonReturn.lastChange;
		appGlobal.lastSynch = Ti.App.Properties.getString('lastSynch');
		appGlobal.licensetbl = jsonReturn.licensetbl;
		Ti.API.info("Licensetbl = " + JSON.stringify(jsonReturn));
		Ti.API.info("Sid = " + appGlobal.licensetbl.licenseSid);
		Ti.API.info("Token = " + appGlobal.licensetbl.licenseToken);
		Ti.API.info("Last DB Change = " + appGlobal.lastChange);
		Ti.API.info("Last Synch = " + appGlobal.lastSynch);
		appGlobal.idOrgTbl = appGlobal.licensetbl.idOrgTbl;

		//appGlobal.tabGroup = Ti.UI.createTabGroup();

		var win = Ti.UI.createWindow({
			title : "MedEdFaculty",
			tabBarHidden : true,
			//backButtonTitle : "Back",
			navBarHidden : true,
			backgroundColor : 'white',
			parentWindow : null,
			exitOnClose : true,
			orientationModes : [Ti.UI.PORTRAIT]
		});

		Ti.App.addEventListener('setLandscape', function() {
			win.orientationModes = [Ti.UI.LANDSCAPE_RIGHT];
			Titanium.UI.orientation = Titanium.UI.LANDSCAPE_RIGHT;
			Ti.API.info("Set to Landscape");
		});

		Ti.App.addEventListener('setPortrait', function() {
			win.orientationModes = [Ti.UI.PORTRAIT];
			Titanium.UI.orientation = Titanium.UI.PORTRAIT;
			Ti.API.info("Set to Portrait");
		});

		if (Ti.Platform.name == 'android') {
			appGlobal.wordWrap = true;
			appGlobal.ellipsize = true;
			var softInput = Ti.UI.Android.SOFT_INPUT_STATE_HIDDEN | Ti.UI.Android.SOFT_INPUT_ADJUST_PAN;
			win.windowSoftInputMode = softInput;
			win.addEventListener('android:back', function(e) {
				e.cancelBubble = true;
				Ti.API.info("Android Back Button = " + appGlobal.androidBackButton);
				Ti.App.fireEvent(appGlobal.androidBackButton);
			});
		}

		if (Ti.Platform.name == 'iOS') {
			appGlobal.wordWrap = false;
			appGlobal.ellipsize = false;
			win.transition = Titanium.UI.iOS.AnimationStyle.FLIP_FROM_LEFT;
			//win.statusBarStyle = Titanium.UI.iOS.StatusBar.TRANSLUCENT_BLACK;
		}

		var mainViewMod = require('ui/handheld/mainView');
		mainViewMod(win);

		win.open();

		processArgs();

	}

}

