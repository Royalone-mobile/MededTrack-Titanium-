function photoView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(11, "photo.png", backFn);

	var currentPhoto = Ti.UI.createImageView({
		width : 'auto',
		height : 'auto',
		top : 0,
		visible : false,
		top : '65dip'
	});

	var viewShield = Ti.UI.createView({
		width : '100%',
		height : '100',
		color : 'black',
		zIndex : 5,
		visible : false,
		top : '65dip'
	});

	var indBar;
	if (Ti.Platform.name == 'android') {
		indBar = Ti.UI.Android.createProgressIndicator({
			  message: 'Loading...',
			  location: Ti.UI.Android.PROGRESS_INDICATOR_DIALOG,
			  type: Ti.UI.Android.PROGRESS_INDICATOR_DETERMINANT,
			  cancelable: true,
			  min: 0,
			  max: 10,
			  width : '200dip',
			  height : '50dip',
			  color : 'white',
			visible : false,
			zIndex : 5
			});
	} else {
		indBar = Titanium.UI.createProgressBar({
			width : '200dip',
			height : '50dip',
			min : 0,
			max : 1,
			value : 0,
			style : Titanium.UI.iOS.ProgressBarStyle.PLAIN,
			message : 'Uploading Image',
			font : {
				fontSize : 18,
				fontWeight : 'bold'
			},
			color : 'white',
			visible : false,
			zIndex : 5
		});
	}
	viewShield.add(indBar);
	self.add(currentPhoto);
	self.add(viewShield);

	Ti.App.addEventListener('photoDialogEvent', photoOptions);

	Ti.App.addEventListener('loadPhoto', loadPhotoFunction);

	Ti.App.addEventListener('resetPhotoView', function() {
		Ti.API.info("Reseting Photo View");
		self.opacity = 1;
		self.zIndex = 20;
		indBar.visible = false;
		indBar.message = 'Uploading Image';
		currentPhoto.opacity = 1;
		viewShield.visible = false;
		if (!appGlobal.idPhotoTbl) {
			Ti.App.fireEvent('loadPhoto');
		} else {
			getPhotoFn();
		}
	});

	function getPhotoFn() {
		getPhoto = require('ui/common/commLink');
		getPhoto({
			request : 'getPhoto',
			idOrgTbl : appGlobal.idOrgTbl,
			deviceID : appGlobal.deviceID,
			idPhotoTbl : appGlobal.idPhotoTbl
		}, getPhotoCB);
	}

	function getPhotoCB(jsonReturn) {
		currentPhoto.image = appGlobal.httpDomain + jsonReturn.imageUrl;
		Ti.API.info("Image URL = " + currentPhoto.image);
		currentPhoto.visible = true;
		Ti.App.fireEvent('photoDialogEvent');
	}

	function photoClose() {
		Ti.API.info("Photo Close");
		var file = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, 'yourPhoto.png');
		var fileDelete = false;

		if (!appGlobal.photo) {
			fileDelete = true;
		}
		indBar.visible = true;
		uploadPhoto({
			photo : file.read(),
			type : 'yourPhoto',
			deviceID : appGlobal.deviceID,
			fileDelete : fileDelete
		}, uploadPhotoCB);

	}

	function photoOptions() {
		var photoOpts = {
			//cancel : 2,
			options : ['Replace', 'Delete', 'Cancel'],
			selectedIndex : 2,
			destructive : 0,
			title : 'Photo Options'
		};

		var photoDialog = Ti.UI.createOptionDialog(photoOpts);

		photoDialog.addEventListener("click", function(e) {
			switch(e.index) {
			case(0):
				Ti.App.fireEvent('loadPhoto');
				photoDialog.hide();
				break;
			case(1):
				if (appGlobal.photo) {
					appGlobal.photo = '';
					Ti.App.Properties.setString('photo', '');
					photoDialog.hide();
					alert("Photo Deleted");
				}
				photoClose();
				break;
			case(2):
				backFn();
				break;
			}
		});
		photoDialog.show();
	}

	function loadPhotoFunction() {
		var opts = {
			//cancel : 2,
			options : ['Take a Photo', 'Select from Gallery', 'Cancel'],
			selectedIndex : 2,
			destructive : 0,
			title : 'Set a Profile Photo:'
		};

		var dialog = Ti.UI.createOptionDialog(opts);
		dialog.show();

		dialog.addEventListener("click", function(e) {
			dialog.hide();
			switch(e.index) {

			case(0):
				Titanium.Media.showCamera({
					allowEditing : true,
					success : function(event) {
						//$.avatar.status = "new";
						//$.avatar.image = event.media;
						var image = event.media;
						var f = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, 'yourPhoto.png');
						f.write(image);
						Ti.App.Properties.setString('photo', f.nativePath);
						currentPhoto.image = f.nativePath;
						appGlobal.photo = f.nativePath;
						Ti.API.info("Photo Path = " + appGlobal.photo);
						f.close;
						photoClose();
						//photoDialog.show();
					},
					cancel :function (event){
						Ti.API.info("Media Cancel");
						backFn();
					},

					error : function(event) {
						console.log(event);
						photoClose();
					}
				});
				break;
			case(1):
				Titanium.Media.openPhotoGallery({
					allowEditing : true,
					success : function(event) {
						var image = event.media;
						var f = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, 'yourPhoto.png');
						f.write(image);
						Ti.App.Properties.setString('photo', 'yourPhoto.png');
						currentPhoto.image = f.nativePath;
						appGlobal.photo = f.nativePath;
						Ti.API.info("Photo Path = " + appGlobal.photo);
						f.close;
						photoClose();
					},
					cancel: function (event){
						Ti.API.info("Media Cancel");
						backFn();
					},

					error : function(event) {
						console.log(event);
						photoClose();
					}
				});
				break;
			case(2):
				backFn();
				break;
			}
		});

	}

	function uploadPhoto(params, callback) {
		indBar.visible = true;
		currentPhoto.opacity = .1;
		/* Create a progress bar */
		viewShield.visible = true;
		var xhr = Titanium.Network.createHTTPClient();
		xhr.onreadystatechange = function() {
			if (this.readyState == 4) {
				callback("Success");
				xhr = null;
			}
		};
		xhr.onsendstream = function(e) {
			indBar.value = e.progress;
			currentPhoto.opacity = e.progress;
			Ti.API.info('ONSENDSTREAM - PROGRESS: ' + e.progress);
		};
		//xhr.setRequestHeader('Content-Type', 'image/png');
		//xhr.setRequestHeader('enctype', 'multipart/form-data');
		xhr.open("POST", appGlobal.imageEndPt);
		xhr.send(params);
	
	}

	function uploadPhotoCB(msg) {
		indBar.message = "Image Uploaded";
		if (msg != "Success") {
			alert("There was a communication failure in saving this picture.  Please try again.");
		}
		var tOut = setTimeout(backFn, 1500);
	}

	function backFn() {
		indBar.visible = false;
		self.zIndex = 21;
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 12;
	}

	return self;

}

module.exports = photoView;
