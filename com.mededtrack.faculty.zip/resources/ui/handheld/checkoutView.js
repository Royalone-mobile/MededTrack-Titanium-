function checkoutView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(15, "checkOut.png", backFn);

	var contentView = Ti.UI.createView({
		height : '78%',
		top : '10%',
		width : '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '3%',
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color : 'black'
	});

	var resName = Ti.UI.createLabel({
		font : {
			fontSize : 16
		},
		top : '18dip',
		left : 0,
		color : 'black'
	});

	resContainer.add(resLabel);
	resContainer.add(resName);

	contentView.add(resContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		top : '51%',
		bottom: '0dp'
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			fontColor : 'black'
		},
		top : '0dip',
		color : 'black',
		left : 0,
		text : "Milestones Selected"
	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		top : '18dip',
		bottom : '20dp',
		borderColor : 'black',
		borderWidth : '1dip',
		touchEnabled : true
	});
	
	var tableAdvice = Ti.UI.createLabel({
		font : {
			fontSize : 12,
			fontColor : 'black'
		},
		bottom : '0dip',
		color : 'black',
		left : 0,
		text : "Milestones can be deleted by swiping left."
	});
	
	if (Ti.Platform.name == 'android') {
		tableAdvice.text = "Milestones can be deleted by long press.";
	}

	var tableData = [];

	viewContainer.add(tableAdvice);
	viewContainer.add(tableLabel);
	viewContainer.add(tableView);

	var observeView = Ti.UI.createView({
		height : '35%',
		width : '85%',
		top : '13%'
	});

	var observeLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		color : 'black',
		left : 0,
		top : 0,
		text : "Observation"
	});

	var observation = Ti.UI.createTextArea({
		width : '98%',
		top : '18dip',
		bottom : 0,
		borderColor : 'black',
		borderWidth : '1dip',
		hintText : 'Observation Text',
		color : 'black',
		autocapitalization : Titanium.UI.TEXT_AUTOCAPITALIZATION_SENTENCES,
		returnKeyType : Titanium.UI.RETURNKEY_GO,
		editable : false
	});

	observeView.add(observeLabel);
	observeView.add(observation);

	contentView.add(viewContainer);
	contentView.add(observeView);
	self.add(contentView);

	var saveButton = Ti.UI.createButton({
		width : '85%',
		height : '35dip',
		color : 'white',
		bottom : '25dip',
		borderRadius : 5,
		borderWidth : '2dp',
		borderColor : 'white',
		title : 'Enter Observation',
		backgroundColor : '#ccc',
		enabled : false
	});

	self.add(saveButton);

	observation.addEventListener('return', function() {
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
	});

	saveButton.addEventListener('doubletap', function() {
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
		observation.blur();
		appGlobal.androidBackButton = null;
		appGlobal.msCart.observation = observation.value;
		var saveObservation = require('ui/common/commLink');
		saveObservation({
			request : 'saveObservation',
			deviceID : appGlobal.deviceID,
			idFacultyTbl : appGlobal.deviceData.idFacultyTbl,
			idResidentTbl : appGlobal.currentRes.idResidentTbl,
			idOrgTbl : appGlobal.deviceData.idOrgTbl,
			msCart : appGlobal.msCart
		}, saveObCB);
	});

	Ti.App.addEventListener('resetCartView', function() {
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.androidBackButton = 'cartBackButton';
		observation.editable = true;
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		observation.value = appGlobal.msCart.observation;
		if (observation.value) {
			enableSave();
		} else {
			disableSave();
		}
		buildTable();

		if (appGlobal.accountVerified == '0') {
			alert("Your email has not been verified.  Until doing so, the Save feature will not be enabled.");
		}
		observation.focus();
	});

	Ti.App.addEventListener('cartBackButton', function() {
		backFn();
	});

	observation.addEventListener('change', function() {
		if (observation.value && appGlobal.accountVerified == '1') {
			enableSave();
		} else {
			disableSave();
		}
	});

	function enableSave() {
		saveButton.enabled = true;
		saveButton.backgroundColor = 'white';
		saveButton.borderColor = '#5a5a5a';
		saveButton.color = 'blue';
		saveButton.title = "Double Tap to Save";
	}

	function disableSave() {
		saveButton.enabled = false;
		saveButton.backgroundColor = '#ccc';
		saveButton.borderColor = 'white';
		saveButton.color = 'white';
		saveButton.title = "Enter Observation";
	}

	function saveObCB() {
		self.zIndex = 21;
		Titanium.Media.vibrate();
		if (appGlobal.playSound) {
			var player = Ti.Media.createSound({
				url : '/sounds/observationSaved.wav'
			});
			player.play();
		}
		appGlobal.msCart.msAr = [];
		appGlobal.msCart.observation = '';
		appGlobal.msCart.filed = true;
		observation.value = '';
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("showAdvice", {
			data : "Observation Recorded"
		});
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function buildTable() {
		tableData = [];
		tableView.setData(tableData);
		for ( i = 0; i < appGlobal.msCart.msAr.length; i++) {
			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '50dip',
				hasChild : false,
				milestonetbl : appGlobal.msCart.msAr[i],
				deleteShown : false,
			});

			var rowView = Ti.UI.createView({
				width : '100%',
				height : '100%',
				zIndex : 1,
				touchEnabled : true,
				sourceName : 'rowView',
				rowIndex : i
			});
			var messageLabel = Ti.UI.createLabel({
				left : '3dip',
				width : '98%',
				height : '33dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 12
				},
				color : 'black',
				wordWrap : appGlobal.wordWrap,
				ellipsize : appGlobal.ellipsize,
				text : appGlobal.msCart.msAr[i].msName
			});

			var deleteButton = Ti.UI.createButton({
				backgroundColor : 'red',
				color : 'white',
				font : {
					fontWeight : "bold",
					fontSize : 18
				},
				title : 'Delete',
				height : '100%',
				width : '100dip',
				right : '-220dip',
				arrayIdx : i
			});

			deleteButton.addEventListener("click", function(e) {
				i = e.source.arrayIdx;
				appGlobal.msCart.msAr.splice(i, 1);
				if (appGlobal.msCart.msAr.length) {
					buildTable();
				} else {
					backFn();
				}
			});

			tableRow.deleteButton = deleteButton;

			if (Ti.Platform.name != 'android') {
				tableRow.addEventListener('swipe', deleteRow);
			} else {
				tableRow.addEventListener('longclick', deleteRow);
			}
			rowView.add(messageLabel);
			rowView.add(deleteButton);
			tableRow.add(rowView);
			tableData.push(tableRow);
		}
		tableView.setData(tableData);

	}

	function deleteRow(e) {
		if (e.row.deleteShown) {
			e.row.deleteButton.animate({
				duration : 800,
				right : '-220dip'
			});
			e.row.deleteShown = false;
		} else {
			e.row.deleteShown = true;
			e.row.deleteButton.animate({
				duration : 800,
				right : 0
			});
		}
	}

	function backFn() {
		observation.blur();
		appGlobal.androidBackButton = null;
		appGlobal.msCart.observation = observation.value;
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}

		self.zIndex = 21;
		appGlobal.backButton = true;
		Ti.App.fireEvent(appGlobal.returnTo);
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 15;
		//self.opacity = 1;
	}

	return self;

};

module.exports = checkoutView;
