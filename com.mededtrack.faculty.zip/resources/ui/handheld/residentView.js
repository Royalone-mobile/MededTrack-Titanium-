function residentView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(11,"resident.png",backFn);
	
	var contentView = Ti.UI.createView({
		height: '90%',
		top: '10%',
		width: '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '395dip',
		top : '3%',
		zIndex : 0,
		//borderColor: 'black',
		//borderWidth: '1dip'
	});
	
	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color: 'black'
	});

	var resName = Ti.UI.createLabel({
		top : '18dip',
		left : 0,
		color: 'black'
	});
	

	var resPicture = Ti.UI.createImageView({
		top : '40dp',
		width : 'auto',
		height : '250dp',
		image : '/images/handheld/blankPerson.png',
		defaultImage : '/images/handheld/blankPerson.png',
		visible : true
	});

	resContainer.add(resLabel);
	resContainer.add(resName);
	resContainer.add(resPicture);

	var buttonView = Ti.UI.createView({
		width : '85%',
		bottom : '30dip',
		height : '150dip',
		zIndex : 5
	});

	var emailButton = Ti.UI.createButton({
		title : "Email",
		width : '45%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top : 0,
		left : 0
	});

	var observartionsButton = Ti.UI.createButton({
		title : "Observations",
		width : '45%',
		height : '45dip',
		borderRadius : 5,
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top: 0,
		right : 0
	});
	
	var callButton = Ti.UI.createButton({
		title : "Call",
		width : '45%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top : '60dp',
		left : 0
	});
	
	var reportButton = Ti.UI.createButton({
		title : "Report",
		width : '45%',
		height : '45dip',
		backgroundColor : 'white',
		color : 'blue',
		borderRadius : 5,
		borderWidth: '2dp',
		borderColor: '#5a5a5a',
		top: '60dp',
		right : 0
	});

	buttonView.add(emailButton);
	buttonView.add(callButton);
	buttonView.add(observartionsButton);
	buttonView.add(reportButton);
	
	contentView.add(buttonView);
	contentView.add(resContainer);
	
	self.add(contentView);

	emailButton.addEventListener("click", function() {
		Ti.API.info("Email Button Click");
		Titanium.Platform.openURL('mailto:' + appGlobal.currentRes.email);
	});
	
	callButton.addEventListener("click", function() {
		Ti.API.info("Call Button Click");
		Titanium.Platform.openURL('tel:' + appGlobal.currentRes.mobilePhone);
	});
	

	observartionsButton.addEventListener("click", function() {
		self.zIndex = 21;
		Ti.App.fireEvent("resetObsView");
		self.animate({duration: 400, opacity: 0}, animateCB);
		
	});
	
	reportButton.addEventListener("click", function() {
		self.zIndex = 21;
		Ti.App.fireEvent("resetReportView");
		self.animate({duration: 400, opacity: 0}, animateCB);
		
	});

	function animateCB() {
		self.zIndex = 11;
		//self.opacity = 1;
	}


	Ti.App.addEventListener('resetResidentView', function() {
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.androidBackButton = 'resBackButton';
		resPicture.image = '/images/handheld/blankPerson.png';
		if (appGlobal.currentRes) {
			resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
			Ti.API.info("Res Name = "+appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName);
			var getPhoto = require('ui/common/commLink');
			getPhoto({
				request : 'getPhoto',
				idResidentTbl : appGlobal.currentRes.idResidentTbl,
				deviceID : appGlobal.deviceID
			}, getPhotoCB);
		} else {
			resPicture.image = '/images/handheld/blankPerson.png';
		}
		
		if (appGlobal.currentRes.email){
			emailButton.enabled = true;
			emailButton.borderColor = '#5a5a5a';
			emailButton.color = 'blue';
			emailButton.backgroundColor = 'white';
		} else {
			emailButton.enabled = false;
			emailButton.borderColor = 'white';
			emailButton.color = 'white';
			emailButton.backgroundColor = '#ccc';
		}
		if (appGlobal.currentRes.mobilePhone){
			callButton.enabled = true;
			callButton.borderColor = '#5a5a5a';
			callButton.color = 'blue';
			callButton.backgroundColor = 'white';
		} else {
			callButton.enabled = false;
			callButton.borderColor = 'white';
			callButton.color = 'white';
			callButton.backgroundColor = '#ccc';
		}
	});
	
	Ti.App.addEventListener('resBackButton', function(){
		backFn();
	});

	function getPhotoCB(jsonReturn) {
		if ( typeof jsonReturn == undefined) {
			alert("Please check network connectivity.  Unable to access server at this time.");
			return false;
		}
		if (jsonReturn.imageUrl) {
			resPicture.image = appGlobal.httpDomain + jsonReturn.imageUrl;
			Ti.API.info("ImageURL = " + jsonReturn.imageUrl);
		} else {
			resPicture.image = '/images/handheld/blankPerson.png';
		}
	}
	
	function backFn(){
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("restartControlView");
		self.animate({duration: 400, opacity: 0}, animateCB);
	}
	
	return self;

};

module.exports = residentView;
