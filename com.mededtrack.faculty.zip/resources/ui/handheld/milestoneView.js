function milestoneView() {

	var ldTimeOut = {};

	var ldOn = false;

	var selfMod = require('ui/common/backView');

	var self = new selfMod(9, "mileStones.png", backFn);

	var activityIndicator = Ti.UI.createActivityIndicator({
		color : 'gray',
		font : {
			fontFamily : 'Helvetica Neue',
			fontSize : 26,
			fontWeight : 'bold'
		},
		message : 'Loading....',
		style : Ti.UI.ActivityIndicatorStyle.DARK,

		height : Ti.UI.SIZE,
		width : Ti.UI.SIZE,
		visible : true
	});

	var blocking = Ti.UI.createView({
		width : '80%',
		height : '75%',
		zIndex : 10,
		backgroundColor : 'white',
		borderColor : 'gray',
		borderRadius : 10,
		borderWidth : '3dp',

	});

	blocking.add(activityIndicator);

	self.add(blocking);

	var contentView = Ti.UI.createView({
		height : '90%',
		top : '10%',
		width : '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '3%'
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color : 'black'
	});

	var resName = Ti.UI.createLabel({
		font : {
			fontSize : 16
		},
		top : '18dip',
		left : 0,
		color : 'black'
	});

	var msCartButton = Ti.UI.createButton({
		borderColor : 'purple',
		borderRadius : '4',
		borderWidth : '2dip',
		backgroundColor : 'white',
		color : 'purple',
		right : '0',
		top : '0dip',
		height : '40dip',
		width : '40dip',

		font : {
			fontWeight : 'bold'
		}
	});

	var longDescView = Ti.UI.createView({
		borderColor : appGlobal.colorOne,
		borderWidth : '1dip',
		borderRadius : 4,
		height : '35%',
		width : '95%',
		backgroundColor : 'white',
		visible : false,
		zIndex : 4
	});

	var longDescMsg = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 16
		},
		color : '#555',
		width : '95%'
	});

	longDescView.add(longDescMsg);

	resContainer.add(resLabel);
	resContainer.add(resName);
	resContainer.add(msCartButton);

	contentView.add(resContainer);

	msCartButton.addEventListener('click', function() {
		if (appGlobal.msCart.msAr.length > 0) {
			self.zIndex = 21;
			Ti.App.fireEvent("resetCartView");
			self.animate({
				duration : 400,
				opacity : 0
			}, animateCB);
		}
	});

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '77%',
		top : '15%'
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			fontColor : 'black'
		},
		top : '0dip',
		color : 'black',
		left : 0,

	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		top : '30dip',
		bottom: '30dip',
		borderColor : 'black',
		borderWidth : '2dip'
	});
	
	var tableAdvice = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			fontColor : 'black'
		},
		bottom : '0dip',
		color : 'black',
		left : 0,
		text: 'Click to select milestone, longpress for complete description'
	});

	viewContainer.add(tableLabel);
	viewContainer.add(tableView);
	viewContainer.add(tableAdvice);
	contentView.add(viewContainer);

	self.add(longDescView);
	self.add(contentView);

	Ti.App.addEventListener("showLongDesc", function(e) {
		Ti.API.info("showLongDesc");
		longDescMsg.text = e.data;
		longDescView.opacity = 1;
		longDescView.visible = true;
		ldTimeOut = setTimeout(function() {
			longDescView.animate({
				duration : 400,
				opacity : 0
			}, endLongDescCB);
		}, 5300);

	});

	longDescView.addEventListener('click', function() {
		clearTimeout(ldTimeOut);
		longDescView.animate({
			duration : 400,
			opacity : 0
		}, endLongDescCB);
	});

	Ti.App.addEventListener('resetMSView', function(e) {
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.returnTo = "resetMSView";
		appGlobal.androidBackButton = "msBackButton";
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		tableLabel.text = appGlobal.currentSubComp.subName + " Milestones";
		msCartButton.title = appGlobal.msCart.msAr.length.toString();
		if (appGlobal.msCart.msAr.length) {
			msCartButton.backgroundColor = 'purple';
			msCartButton.color = 'white';
			msCartButton.enabled = true;
		} else {
			msCartButton.enable = false;
			msCartButton.backgroundColor = 'white';
			msCartButton.color = 'purple';
		}
		getmilestonesFn();
	});

	Ti.App.addEventListener('msBackButton', function() {
		backFn();
	});

	function getmilestonesFn() {
		blocking.show();
		var getMileStones = require('ui/common/commLink');
		getMileStones({
			request : 'getMilestones',
			idSubCompTbl : appGlobal.currentSubComp.idSubCompTbl,
			idResidentTbl : appGlobal.currentRes.idResidentTbl,
			idSpecialtyTbl : appGlobal.currentRes.idSpecialtyTbl,
			deviceID : appGlobal.deviceID
		}, getmilestonesCB);
	}

	function getmilestonesCB(jsonReturn) {
		if ( typeof jsonReturn.milestoneAr == 'undefined') {
			blocking.hide();
			alert("Unable to communicate with service at this time.  Please try again later.");
			backFn();
			return false;
		}
		appGlobal.milestoneAr = jsonReturn.milestoneAr;
		appGlobal.obsAr = jsonReturn.obsAr;
		appGlobal.attainedAr = jsonReturn.attainedAr;
		appGlobal.possibleAr = jsonReturn.possibleAr;
		appGlobal.scoreAr = jsonReturn.scoreAr;
		appGlobal.scoreArStr = jsonReturn.scoreArStr;
		Ti.API.info('Milestone Ar = ' + JSON.stringify(appGlobal.milestoneAr));
		Ti.API.info('obsAr = ' + JSON.stringify(appGlobal.obsAr));
		Ti.API.info('attainedAr = ' + JSON.stringify(appGlobal.attainedAr));
		Ti.API.info('possibleAr = ' + JSON.stringify(appGlobal.possibleAr));
		Ti.API.info('scoreAr = ' + JSON.stringify(appGlobal.scoreAr));
		buildTable();
	}

	function buildTable() {

		tableData = [];
		tableView.setData(tableData);
		var msLevel = null;
		var sections = [];
		for ( i = 0; i < appGlobal.milestoneAr.length; i++) {
			if (msLevel == null || msLevel != appGlobal.milestoneAr[i].msLevel) {
				msLevel = appGlobal.milestoneAr[i].msLevel;
				Ti.API.info("building level " + msLevel);
				sections.push(buildSections(msLevel));
			}
		}
		tableView.setData(sections);
		blocking.hide();
	}

	function buildSections(msLevel) {
		var section = Ti.UI.createTableViewSection({
			headerView : tableSectionView(msLevel)
		});
		for ( k = 0; k < appGlobal.milestoneAr.length; k++) {

			if (msLevel == appGlobal.milestoneAr[k].msLevel) {
				var milestone = getMS(appGlobal.milestoneAr[k].idMileStoneTbl);

				var tableRow = Ti.UI.createTableViewRow({
					backgroundColor : 'white',
					touchEnabled : true,
					height : '50dip',
					hasChild : false,
					milestonetbl : appGlobal.milestoneAr[k]
				});

				var rowView = Ti.UI.createView({
					width : '100%',
					height : '100%',
					zIndex : 1
				});
				var messageLabel = Ti.UI.createLabel({
					left : '3dip',
					width : '95%',
					height : '33dip',
					font : {
						fontWeight : 'Bold',
						fontSize : 12
					},
					color : appGlobal.colorOne,
					wordWrap : appGlobal.wordWrap,
					ellipsize : appGlobal.ellipsize,
					text : milestone.msName
				});

				var obsNum = Ti.UI.createLabel({
					right : '3dip',

					height : '33dip',
					font : {
						fontWeight : 'Bold',
						fontSize : 14
					},
					color : 'black',
					backgroundColor : 'yellow',
					textAlign : Ti.UI.TEXT_ALIGNMENT_CENTER,
					visible : false,
					width : '9%'
				});

				if (appGlobal.obsAr[k] > 0) {
					messageLabel.width = '88%';
					obsNum.text = appGlobal.obsAr[k];
					if (appGlobal.obsAr[k] >= appGlobal.milestoneAr[k].minAchievement) {
						obsNum.backgroundColor = 'green';
					}
					obsNum.visible = true;
				}

				if (chkUse(appGlobal.milestoneAr[k].idMileStoneTbl)) {
					messageLabel.color = '#444';
				}

				rowView.add(messageLabel);
				rowView.add(obsNum);
				tableRow.add(rowView);

				tableRow.addEventListener('longpress', function(e) {
					ldOn = true;
					Ti.API.info("LongPress");
					appGlobal.currentMilestone = e.row.milestonetbl;
					Ti.App.fireEvent('showLongDesc', {
						data : appGlobal.currentMilestone.msDescription
					});
				});

				tableRow.addEventListener('click', function(e) {
					if (!ldOn) {
						appGlobal.currentMilestone = e.row.milestonetbl;

						if (!chkUse(appGlobal.currentMilestone.idMileStoneTbl)) {
							e.source.color = '#444';
							appGlobal.msCart.msAr.push(e.row.milestonetbl);
							msCartButton.title = appGlobal.msCart.msAr.length.toString();
							msCartButton.title = appGlobal.msCart.msAr.length.toString();
							msCartButton.backgroundColor = 'purple';
							msCartButton.color = 'white';
							Titanium.Media.vibrate();

							var player = Ti.Media.createSound({
								url : '/sounds/goodRead.wav'
							});
							player.play();

						}
					}
				});

				tableRow.addEventListener('longpress', function(e) {
					Ti.API.info("LongPress");
					appGlobal.currentMilestone = e.row.milestonetbl;
					Ti.App.fireEvent('showLongDesc', {
						data : appGlobal.currentMilestone.msDescription
					});
				});

				section.add(tableRow);

			}

		}

		return section;
	}

	function chkUse(idMileStoneTbl) {
		var found = false;
		for ( h = 0; h < appGlobal.msCart.msAr.length; h++) {
			if (idMileStoneTbl == appGlobal.msCart.msAr[h].idMileStoneTbl) {
				found = true;
			}
		}
		return found;
	}

	function showPicker() {
		self.zIndex = 9;

	}

	function tableSectionView(msLevel) {
		var sectionName = "Milestone Level " + msLevel;

		var ts = Ti.UI.createView({
			width : '100%',
			height : '40dip',
			backgroundColor : 'white',
			borderColor : appGlobal.colorOne,
			borderWidth : '1dip'
		});
		var sl = Ti.UI.createLabel({
			font : {
				fontSize : 14,
				fontWeight : 'bold'
			},
			color : 'black',
			text : sectionName,
			left : '5%'
		});

		var scoreLb = Ti.UI.createLabel({
			font : {
				fontSize : 14,
				fontWeight : 'bold'
			},
			color : 'black',
			text : appGlobal.scoreArStr[msLevel - 1],
			right : '5%'
		});

		ts.add(sl);
		ts.add(scoreLb);
		return ts;
	}

	function backFn() {
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("resetSubCompView");
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 9;
		//self.opacity = 1;
	}

	function endLongDescCB() {
		ldOn = false;
		longDescView.visible = false;
		longDescView.opacity = 0;
	};

	function getMS(idMileStoneTbl) {
		Ti.API.info("Getting MS for " + idMileStoneTbl);
		var db = Ti.Database.open('metDB');
		var msRS = db.execute('SELECT idMileStoneTbl, msName, msDescription, idSpecialtyTbl FROM milestonetbl WHERE idMileStoneTbl = ?', idMileStoneTbl);
		while (msRS.isValidRow()) {
			var msName = msRS.fieldByName('msName');
			Ti.API.info("Found MS = " + msName);
			var idMileStoneTbl = msRS.fieldByName('idMileStoneTbl');
			var idSpecialtyTbl = msRS.fieldByName('idSpecialtyTbl');
			var msDescription = msRS.fieldByName('msDescription');
			msRS.next();
		}
		msRS.close();
		var milestone = {
			msName : msName,
			idMileStoneTbl : idMileStoneTbl,
			idSpecialtyTbl : idSpecialtyTbl,
			msDescription : msDescription
		};
		return milestone;
	}

	return self;

};

module.exports = milestoneView;
