function obsOnlyView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(16, "checkOut.png", backFn);

	var contentView = Ti.UI.createView({
		height : '90%',
		top : '10%',
		width : '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '3%',
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color : 'black'
	});

	var resName = Ti.UI.createLabel({
		font : {
			fontSize : 16
		},
		top : '18dip',
		left : 0,
		color : 'black'
	});

	resContainer.add(resLabel);
	resContainer.add(resName);

	contentView.add(resContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '35%',
		top : '51%'
	});

	var observeView = Ti.UI.createView({
		height : '35%',
		width : '85%',
		top : '13%'
	});

	var observeLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		color : 'black',
		left : 0,
		top : 0,
		
	});

	var observation = Ti.UI.createTextArea({
		width : '100%',
		top : '32dip',
		bottom : 0,
		borderColor : 'black',
		borderWidth : '1dip',
		hintText : 'General Observation Text',
		color : 'black',
		autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_SENTENCES,
		returnKeyType : Titanium.UI.RETURNKEY_GO,
		editable : false
	});

	observeView.add(observeLabel);
	observeView.add(observation);

	contentView.add(viewContainer);
	contentView.add(observeView);
	self.add(contentView);

	var saveButton = Ti.UI.createButton({
		width : '85%',
		height : '35dip',
		color : 'white',
		bottom : '25dip',
		borderRadius : 5,
		borderWidth : '2dp',
		borderColor : 'white',
		title : 'Enter Observation',
		backgroundColor : '#ccc',
		enabled : false
	});

	self.add(saveButton);

	observation.addEventListener('return', function() {
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
	});

	saveButton.addEventListener('doubletap', function() {
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
		observation.blur();
		appGlobal.androidBackButton = null;
		appGlobal.msCart.observation = observation.value;
		var saveObservation = require('ui/common/commLink');
		saveObservation({
			request : 'saveGeneralObservation',
			deviceID : appGlobal.deviceID,
			idFacultyTbl : appGlobal.deviceData.idFacultyTbl,
			idResidentTbl : appGlobal.currentRes.idResidentTbl,
			idOrgTbl : appGlobal.deviceData.idOrgTbl,
			observation: observation.value,
			idSubCompTbl: appGlobal.currentSubComp.idSubCompTbl
		}, saveObCB);
	});

	Ti.App.addEventListener('resetObsOnly', function() {
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.androidBackButton = 'obsCartBackButton';
		observation.editable = true;
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		observeLabel.text = "General Observation for " + appGlobal.currentSubComp.subName;
		observation.value = appGlobal.msCart.observation;
		if (observation.value) {
			enableSave();
		} else {
			disableSave();
		}

		if (appGlobal.accountVerified == '0') {
			alert("Your email has not been verified.  Until doing so, the Save feature will not be enabled.");
		}
		observation.focus();
	});

	Ti.App.addEventListener('obsCartBackButton', function() {
		backFn();
	});

	observation.addEventListener('change', function() {
		if (observation.value && appGlobal.accountVerified == '1') {
			enableSave();
		} else {
			disableSave();
		}
	});

	function enableSave() {
		saveButton.enabled = true;
		saveButton.backgroundColor = 'white';
		saveButton.borderColor = '#5a5a5a';
		saveButton.color = 'blue';
		saveButton.title = "Double Tap to Save";
	}

	function disableSave() {
		saveButton.enabled = false;
		saveButton.backgroundColor = '#ccc';
		saveButton.borderColor = 'white';
		saveButton.color = 'white';
		saveButton.title = "Enter Observation";
	}

	function saveObCB() {
		self.zIndex = 21;
		Titanium.Media.vibrate();
		var player = Ti.Media.createSound({
			url : '/sounds/observationSaved.wav'
		});
		player.play();
		appGlobal.msCart.msAr = [];
		appGlobal.msCart.observation = '';
		appGlobal.msCart.filed = true;
		observation.value = '';
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("showAdvice", {
			data : "Observation Recorded"
		});
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function backFn() {
		observation.blur();
		appGlobal.androidBackButton = null;
		appGlobal.msCart.observation = observation.value;
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}

		self.zIndex = 21;
		appGlobal.backButton = true;
		Ti.App.fireEvent("resetSubCompView");
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 15;
		//self.opacity = 1;
	}

	return self;

};

module.exports = obsOnlyView;
