function obsView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(14,"observationHistory.png",backFn);
	
	var contentView = Ti.UI.createView({
		height: '90%',
		top: '10%',
		width: '100%'
	});

	var obsContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '3%'
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color: 'black'
	});

	var resName = Ti.UI.createLabel({
		top : '18dip',
		left : 0,
		color: 'black'
	});

	obsContainer.add(resLabel);
	obsContainer.add(resName);
	
	contentView.add(obsContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '75%',
		top : '15%'
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		top : '0dip',
		color : 'black',
		left : 0,
		text : "Observation History"
	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		height : '90%',
		top : '18dip',
		borderColor : 'black',
		borderWidth : '1dip'
	});

	viewContainer.add(tableLabel);
	viewContainer.add(tableView);
	
	contentView.add(viewContainer);
	
	var activityIndicator = Ti.UI.createActivityIndicator({
		color : 'gray',
		font : {
			fontFamily : 'Helvetica Neue',
			fontSize : 26,
			fontWeight : 'bold'
		},
		message : 'Loading....',
		style : Ti.UI.ActivityIndicatorStyle.DARK,

		height : Ti.UI.SIZE,
		width : Ti.UI.SIZE,
		visible: true
	});
	
	var blocking = Ti.UI.createView({
		width: '80%',
		height: '75%',
		zIndex: 10,
		backgroundColor: 'white',
		borderColor: 'gray',
		borderRadius: 10,
		borderWidth: '3dp',
		
	});
	
	blocking.add(activityIndicator);

	self.add(blocking);
	
	
	self.add(contentView);
	

	Ti.App.addEventListener('resetObsView', function() {
			tableData = [];
		    tableView.setData(tableData);
			self.zIndex = 20;
			self.opacity = 1;
			appGlobal.androidBackButton = 'obsBackButton';
			getObsFn();
	});
	
	Ti.App.addEventListener('obsBackButton', function(){
		backFn();
	});


	function getObsFn() {
		blocking.show();
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		var getObs = require('ui/common/commLink');
		Ti.API.info(JSON.stringify(appGlobal.currentRes));
		getObs({
			request : 'getObs',
			idResidentTbl : appGlobal.currentRes.idResidentTbl
		}, getObsCB);
	}

	function getObsCB(jsonReturn) {
		if ( typeof jsonReturn.obsAr == 'undefined') {
			blocking.hide();
			alert("Unable to communicate with service at this time.  Please try again later.");
			return false;
		}
		appGlobal.obsAr = jsonReturn.obsAr;
		Ti.API.info('Obs Ar = ' + JSON.stringify(appGlobal.obsAr));

		buildTable();
	}

	function buildTable() {
		
		for ( k = 0; k < appGlobal.obsAr.length; k++) {
			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '55dip',
				hasChild : true,
				obsdatatbl : appGlobal.obsAr[k],
				borderColor : appGlobal.colorOne,
				borderWidth : '1dip'
			});

			var rowView = Ti.UI.createView({
				width : '100%',
				height : '100%',
				zIndex : 1,

			});
			var messageLabel = Ti.UI.createLabel({
				left : '3dip',
				width : '85%',
				height : '50dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 16
				},
				color : appGlobal.colorOne,
				wordWrap : appGlobal.wordWrap,
				ellipsize : appGlobal.ellipsize,
				text : appGlobal.obsAr[k].obsDescription
			});
			
			labelRight = Ti.UI.createLabel({
				right : '3dip',
				width : '12%',
				height : '50dip',
				font : {
					fontSize : 10
				},
				wordWrap : true,
				ellipsize : true,
				
			});
			
			if (appGlobal.obsAr[k].noMs > 0){
				labelRight.color = 'black';
				labelRight.text = appGlobal.obsAr[k].noMs+ " MS";
			} else {
				labelRight.color = 'black';
				labelRight.text = "GO";
			}

			rowView.add(messageLabel);
			rowView.add(labelRight);
			tableRow.add(rowView);
			tableData.push(tableRow);
			tableRow.addEventListener('click', function(e) {
				appGlobal.obsData = e.row.obsdatatbl;
				self.zIndex = 21;
				Ti.App.fireEvent('resetObsDetail');
				self.animate({duration: 400, opacity: 0}, animateCB);
			});

		}
		tableView.setData(tableData);
		blocking.hide();
	}
	
	function backFn(){
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("resetResidentView");
		self.animate({duration: 400, opacity: 0}, animateCB);
	}
	
	function animateCB(){
		self.zIndex = 14;
		//self.opacity = 1;
	}

	return self;

};

module.exports = obsView;
