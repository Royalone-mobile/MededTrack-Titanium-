function obsDetailView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(15, "observationDetail.png", backFn);

	var contentView = Ti.UI.createView({
		height : '80%',
		top : '10%',
		width : '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '2%'
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color : 'black'
	});

	var resName = Ti.UI.createLabel({
		top : '18dip',
		left : 0,
		color : 'black'
	});

	var facultyLabel = Ti.UI.createLabel({
		text : 'Faculty',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		right : 0,
		top : 0,
		width : '48%',
		textAlign : Ti.UI.TEXT_ALIGNMENT_RIGHT,
		color : 'black'
	});

	var facultyName = Ti.UI.createLabel({
		color : 'black',
		top : '18dip',
		width : '48%',
		right : 0,
		textAlign : Ti.UI.TEXT_ALIGNMENT_RIGHT
	});

	resContainer.add(resLabel);
	resContainer.add(resName);
	resContainer.add(facultyLabel);
	resContainer.add(facultyName);

	contentView.add(resContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		top : '51%',
		bottom : '0dip'
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			fontColor : 'black'
		},
		top : '0dip',
		color : 'black',
		left : 0,
		text : "Milestones"
	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		top : '18dip',
		bottom : '30dp',
		borderColor : 'black',
		borderWidth : '1dip',
		touchEnabled : true
	});

	var tableAdvice = Ti.UI.createLabel({
		font : {
			fontSize : 12,
			fontColor : 'black'
		},
		bottom : '0dip',
		color : 'black',
		left : 0,
		text : "Milestones in red can be deleted by swiping left."
	});

	if (Ti.Platform.name == 'android') {
		tableAdvice.text = "Milestones in red can be deleted by long press.";
	}
	var tableData = [];

	viewContainer.add(tableLabel);
	viewContainer.add(tableView);
	viewContainer.add(tableAdvice);

	var observeView = Ti.UI.createView({
		height : '35%',
		width : '85%',
		top : '13%'
	});

	var observeLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,

		},
		color : 'black',
		left : 0,
		top : 0,
		color : 'black'
	});

	var obsScroll = Ti.UI.createScrollView({
		width : '100%',
		height : 'auto',
		borderColor : 'black',
		borderWidth : '1dp',
		top : '18dp',
	});

	var observation = Ti.UI.createLabel({
		width : '98%',
		color : 'black',
		top : 0
	});

	obsScroll.add(observation);

	observeView.add(observeLabel);
	observeView.add(obsScroll);

	contentView.add(viewContainer);
	contentView.add(observeView);

	self.add(contentView);

	Ti.App.addEventListener('resetObsDetail', function() {

		appGlobal.androidBackButton = 'detailBackButton';
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		facultyName.text = appGlobal.obsData.facultyName;
		observeLabel.text = "Observation on " + appGlobal.obsData.obsDateLong;
		observation.text = appGlobal.obsData.observation;
		if (!appGlobal.obsData.subCompID) {
			tableView.visible = true;
			tableAdvice.visible = true;
			tableLabel.visible = true;
			tableLabel.text = "Milestones";
			buildTable();
		} else {
			tableView.visible = false;
			tableAdvice.visible = false;
			tableLabel.text = "General Observation on " + appGlobal.obsData.subName;
		}

		self.zIndex = 20;
		self.opacity = 1;
	});

	Ti.App.addEventListener('detailBackButton', function() {
		backFn();
	});

	function buildTable() {
		tableData = [];
		tableView.setData(tableData);
		var timeNow = Math.round(new Date().getTime() / 1000);
		for ( i = 0; i < appGlobal.obsData.msAr.length; i++) {
			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '50dip',
				hasChild : false,
				milestonetbl : appGlobal.obsData.msAr[i],
				deleteShown : false,
			});

			var rowView = Ti.UI.createView({
				width : '100%',
				height : '100%',
				zIndex : 1,
				touchEnabled : true,
				sourceName : 'rowView',
				rowIndex : i
			});
			var messageLabel = Ti.UI.createLabel({
				left : '3dip',
				width : '100%',
				height : '33dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 12
				},
				color : 'black',
				wordWrap : appGlobal.wordWrap,
				ellipsize : appGlobal.ellipsize,
				text : appGlobal.obsData.msAr[i].subShort + ' ' + appGlobal.obsData.msAr[i].msName,
				zIndex : 1
			});

			var deleteButton = Ti.UI.createButton({
				backgroundColor : 'red',
				color : 'white',
				font : {
					fontWeight : "bold",
					fontSize : 18
				},
				title : 'Delete',
				height : '100%',
				width : '100dip',
				right : '-220dip',
				arrayIdx : i,
				zIndex : 90
			});

			deleteButton.addEventListener("click", function(e) {
				i = e.source.arrayIdx;
				appGlobal.arrayIdx = i;
				var delObs = require('ui/common/commLink');
				delObs({
					request : 'deleteObsData',
					idObsDataTbl : appGlobal.obsData.msAr[i].idObsDataTbl,
					idObserveTbl : appGlobal.obsData.msAr[i].idObserveTbl
				}, deleteCB);
			});

			tableRow.deleteButton = deleteButton;

			if (Ti.Platform.name != 'android') {
				tableRow.addEventListener('swipe', deleteRow);
			} else {
				tableRow.addEventListener('longclick', deleteRow);
			}
			if (timeNow - appGlobal.obsData.obsDate < 259200 && appGlobal.obsData.idFacultyTbl == appGlobal.idFacultyTbl) {
				rowView.add(deleteButton);
				messageLabel.color = 'red';
			}

			rowView.add(messageLabel);

			tableRow.add(rowView);
			tableData.push(tableRow);
		}
		tableView.setData(tableData);

	}

	function deleteCB() {
		i = appGlobal.arrayIdx;
		appGlobal.obsData.msAr.splice(i, 1);
		if (appGlobal.obsData.msAr.length) {
			buildTable();
		} else {
			backFn();
		}
	};

	function deleteRow(e) {
		if (e.row.deleteShown) {
			e.row.deleteButton.animate({
				duration : 800,
				right : '-220dip'
			});
			e.row.deleteShown = false;
		} else {
			e.row.deleteShown = true;
			e.row.deleteButton.animate({
				duration : 800,
				right : 0
			});
		}
	}

	function backFn() {
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("resetObsView");
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 15;
		//self.opacity = 1;
	}

	return self;

};

module.exports = obsDetailView;
