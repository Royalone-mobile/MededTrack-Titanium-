function selectCalendar(win) {

	var headerViewMod = require('ui/handheld/headerView');
	var headerView = headerViewMod('Select Calendar', backButton);

	win.add(headerView);

	var calendarContainer = Ti.UI.createView({
		backgroundColor : 'white',
		width : '100%',
		height : '80%',
		top : '65dip',
	});

	var calendarView = Ti.UI.createView({
		backgroundColor : 'white',
		width : '90%',
		height : 'auto',
		top : '15dip'
	});

	var table = Ti.UI.createTableView({
		width : '100%',
		height : '100%'
	});

	var tableData = [];

	buildTable();

	calendarContainer.add(table);

	win.add(calendarContainer);

	win.addEventListener('close', saveData);

	function backButton() {
		win.close();
	}

	function saveData() {
		Ti.App.Properties.setString("calendarIndex", appGlobal.calendarIndex);
	}

	function buildTable() {
		var calendars = {};
		if (Titanium.Platform.osname == 'iphone') {
				Ti.API.info("Creating Calendar Event for iOS");
				if (Ti.Calendar.eventsAuthorization == Ti.Calendar.AUTHORIZATION_AUTHORIZED) {
					Ti.API.info("Event Authorized");
					calendars = Ti.Calendar.allEditableCalendars;
				} else {
					Ti.API.info("Event Needs Authorization");
					Ti.Calendar.requestEventsAuthorization(function(e) {
						if (e.success) {
							calendars = Ti.Calendar.allEditableCalendars;
						} else {
							alert('Access to calendar is not allowed');
						}
					});
				}
			} else {
				Ti.API.info("Creating Calendar Event for non-iOS");
				calendars = Ti.Calendar.allEditableCalendars;
			}
		
		tableData = [];
		table.setData(tableData);
		Ti.API.info("Current Calendar Index = "+appGlobal.calendarIndex);
		for (var j = 0; j < calendars.length; j++) {
			Ti.API.info(calendars[j].name+ " ID = "+ calendars[j].id);
			var subscribed = '';

			if (appGlobal.calendarIndex == calendars[j].id) {
				subscribed = '✓';
			}
			var rowView = Ti.UI.createView({
				width : '95%',
				height : '50dip',
				index : j,
			});
			var rowLabel = Ti.UI.createLabel({
				text : calendars[j].name,
				width : '80%',
				left : 0
			});

			var subscriptionSwitch = Ti.UI.createLabel({
				text : subscribed,
				
				right : '10dip',
				color: 'black',
				font: {fontWeight: 'bold', fontSize: 16}
			});

			rowView.addEventListener('click', function(e) {
				var cals = Ti.Calendar.allEditableCalendars;
				appGlobal.calendarIndex = cals[e.index].id;
				buildTable();
			});

			rowView.add(rowLabel, subscriptionSwitch);

			var tableRow = Ti.UI.createTableViewRow({

			});
			tableRow.add(rowView);
			tableData.push(tableRow);
		}

		table.setData(tableData);

	}

}

module.exports = selectCalendar;
