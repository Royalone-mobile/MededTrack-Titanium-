function mainView(win) {
	
	var activateViewMod = require('ui/handheld/activateView');
	var activateView = new activateViewMod();
	
	var activationViewMod = require('ui/handheld/activationView');
	var activationView = new activationViewMod();
	
	var activateViewMod = require('ui/handheld/activateView');
	var activateView = new activateViewMod();

	win.add(activateView);
	win.add(activationView);

	var licViewMod = require('ui/handheld/licenseView');
	var licView = new licViewMod();

	var controlViewMod = require("ui/handheld/controlView");
	var controlView = new controlViewMod(win);

	var competencyViewMod = require('ui/handheld/competencyView');
	var competencyView = new competencyViewMod();

	var subCompViewMod = require('ui/handheld/subCompView');
	var subCompView = new subCompViewMod();

	var milestoneViewMod = require('ui/handheld/milestoneView');
	var milestoneView = new milestoneViewMod();
	
	var milestoneSearchMod = require('ui/handheld/milestoneSearch');
	var milestoneSearch = new milestoneSearchMod();

	var checkoutViewMod = require('ui/handheld/checkoutView');
	var checkoutView = new checkoutViewMod();
	
	var obsOnlyViewMod = require('ui/handheld/obsOnlyView');
	var obsOnlyView = new obsOnlyViewMod();

	var settingsViewMod = require('ui/handheld/settingsView');
	var settingsView = settingsViewMod(win);

	var residentViewMod = require('ui/handheld/residentView');
	var residentView = residentViewMod(win);

	var blankViewMod = require('ui/handheld/blankView');
	var blankView = blankViewMod();

	var thisAppMod = require('ui/handheld/thisApp');
	var thisAppView = thisAppMod();

	var emailViewMod = require('ui/handheld/emailEdit');
	var emailView = emailViewMod();

	var phoneViewMod = require('ui/handheld/phoneEdit');
	var phoneView = phoneViewMod();

	var photoViewMod = require('ui/handheld/photoView');
	var photoView = photoViewMod();

	var obsViewMod = require("ui/handheld/obsView");
	var obsView = obsViewMod();

	var obsDetailViewMod = require("ui/handheld/obsDetailView");
	var obsDetailView = obsDetailViewMod();

	var updateViewMod = require("ui/handheld/updateView");
	var updateView = updateViewMod();
	
	var rptViewMod = require("ui/handheld/reportView");
	var rptView = rptViewMod();

	win.add(licView);
	win.add(controlView);
	win.add(competencyView);
	win.add(subCompView);
	win.add(milestoneView);
	win.add(milestoneSearch);
	win.add(checkoutView);
	win.add(obsOnlyView);
	win.add(settingsView);
	win.add(residentView);
	win.add(blankView);
	win.add(thisAppView);
	win.add(emailView);
	win.add(phoneView);
	win.add(photoView);
	win.add(obsView);
	win.add(obsDetailView);
	win.add(updateView);
	win.add(rptView);

	if (!appGlobal.licensetbl.licenseNumber || !appGlobal.licensetbl.licenseSid || !appGlobal.licensetbl.licenseToken || !appGlobal.idOrgTbl) {
		Ti.App.fireEvent('licenseCheck');
	} else {
		if (appGlobal.lastSynch < appGlobal.lastChange || appGlobal.lastSynch == null) {
			Ti.App.fireEvent('resetUpdate');
		} else {
			Ti.App.fireEvent('restartControlView');
		}
	}

	if (Ti.Platform.name == 'android') {
		Ti.UI.Android.hideSoftKeyboard();
	}
}

module.exports = mainView;
