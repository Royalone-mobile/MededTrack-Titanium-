function emailEdit() {
	var selfMod = require('ui/common/backView');

	var self = new selfMod(12,"email.png",backFn);
	
	var emailContainer = Ti.UI.createView({
		backgroundColor : 'white',
		width : '100%',
		height : '80%',
		top : '65dip'
	});

	var emailView = Ti.UI.createView({
		backgroundColor : 'white',
		width : '95%',
		height : 'auto',
		top : '15dip'
	});


	var firstNameLabel = Ti.UI.createLabel({
		font : {
			fontSize : 14,
			fontWeight : 'bold'
		},
		text : 'First Name',
		left : '6%',
		top : '0dip',
		color: 'black'
	});

	var firstName = Ti.UI.createTextField({
		height : '45dip',
		width : '88%',
		borderWidth : '2dp',
		borderColor : 'gray',
		borderRadius : 6,
		paddingLeft : '6dp',
		left : '6%',
		top : '22dip',
		paddingLeft : '3dip',
		clearButtonMode : Titanium.UI.INPUT_BUTTONMODE_ALWAYS,
		color: 'black',
		returnKeyType: Titanium.UI.RETURNKEY_DONE,
		editable: false
	});

	var lastNameLabel = Ti.UI.createLabel({
		font : {
			fontSize : 14,
			fontWeight : 'bold'
		},
		text : 'Last Name',
		left : '6%',
		top : '79dip',
		color: 'black'
	});

	var lastName = Ti.UI.createTextField({
		height : '45dip',
		width : '88%',
		borderWidth : '2dp',
		borderColor : 'gray',
		borderRadius : 6,
		paddingLeft : '6dp',
		left : '6%',
		top : '102dip',
		paddingLeft : '3dip',
		clearButtonMode : Titanium.UI.INPUT_BUTTONMODE_ALWAYS,
		color: 'black',
		returnKeyType: Titanium.UI.RETURNKEY_DONE,
		editable: false
	});

	var emailLabel = Ti.UI.createLabel({
		font : {
			fontSize : 14,
			fontWeight : 'bold'
		},
		text : 'Email Address',
		left : '6%',
		top : '158dip',
		color: 'black'
	});

	var email = Ti.UI.createTextField({
		height : '45dip',
		width : '88%',
		borderWidth : '2dp',
		borderColor : 'gray',
		borderRadius : 6,
		paddingLeft : '6dp',
		left : '6%',
		top : '180dip',
		paddingLeft : '3dip',
		clearButtonMode : Titanium.UI.INPUT_BUTTONMODE_ALWAYS,
		color: 'black',
		returnKeyType: Titanium.UI.RETURNKEY_DONE,
		editable: false
	});

	var verifyEmailButton = Ti.UI.createButton({
		title : 'Verify Email Address',
		width : '75%',
		height : '45dip',
		top : '247dip',
		visible : false,
		backgroundColor : 'yellow',
		color : 'black',
		borderWidth : '1dip',
		borderColor : 'black',
		borderRadius : 2
	});

	verifyEmailButton.addEventListener('click', verifyEmail);

	emailView.add(firstNameLabel);
	emailView.add(firstName);
	emailView.add(lastNameLabel);
	emailView.add(lastName);
	emailView.add(emailLabel);
	emailView.add(email);

	emailView.add(emailLabel);
	emailView.add(email);
	emailView.add(verifyEmailButton);
	emailContainer.add(emailView);

	self.add(emailContainer);

	email.addEventListener('change', function(){
		setVerifyButton();
	});
	
	Ti.App.addEventListener('resetEmailView', function(){
		lastName.editable = true;
		firstName.editable = true;
		email.editable = true;
		Ti.API.info("Reseting This App View");
		self.opacity = 1;
		self.zIndex = 20;
		getDeviceSettings();
	});
	

	function getDeviceSettings(){
		 Ti.API.info("Getting device settings");
		var getDeviceSettings = require('ui/common/commLink');
		getDeviceSettings({
			request : 'getDeviceSettings',
			deviceID : appGlobal.deviceID
		}, getDeviceSettingsCB);
	}

	function backFn() {
		firstName.blur();
		lastName.blur();
		email.blur();
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
		saveData();
		self.zIndex = 21;
		self.animate({duration: 400, opacity: 0}, animateCB);
	}

	function getDeviceSettingsCB(json) {
		if ( typeof json.results == 'undefined') {
			alert("Unable to communicate with host at this time.  Please try again later.");
			return false;
		}
		Ti.API.info("Device Settings = "+JSON.stringify(json));
		appGlobal.results = json.results;
		
		appGlobal.faculty.email = json.results.email;
		appGlobal.faculty.firstName = json.results.firstName;
		appGlobal.faculty.lastName = json.results.lastName;
		//appGlobal.faculty.employeeNumber = json.results.employeeNumber;
		firstName.value = appGlobal.faculty.firstName;
		lastName.value = appGlobal.faculty.lastName;
		email.value = appGlobal.faculty.email;
		
		setVerifyButton();
		firstName.focus();
	}
	
	function setVerifyButton(){
		var emailAddr = email.value;
		var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

		if (appGlobal.results.accountVerified != '1' && !reg.test(emailAddr)) {
			verifyEmailButton.visible = true;
			verifyEmailButton.opacity = .5;
			verifyEmailButton.enabled = false;
		}
		
		if (appGlobal.results.accountVerified != '1' && reg.test(emailAddr)) {
			verifyEmailButton.visible = true;
			verifyEmailButton.opacity = 1;
			verifyEmailButton.enabled = true;
		}
		if (appGlobal.results.accountVerified == '1'){
			verifyEmailButton.visible = false;
		}
	}

	function saveData() {
		var saveData = require('ui/common/commLink');
		Ti.API.info("Saving Your Data Data");
		saveData({
			request : 'saveFacultyData',
			deviceID : appGlobal.deviceID,
			company: appGlobal.faculty.company,
			firstName: firstName.value,
			lastName: lastName.value,
			email: email.value
		}, saveDataCB);
	}

	function saveDataCB() {
		//getDeviceSettings();
	}

	
	function verifyEmail() {
		var emailAddr = email.value;
		var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

		if (reg.test(emailAddr) == false) {
			alert("Not a valid email address.  Please enter again.");
			return;
		}	
			saveData();
			var verifyMsg = require('ui/common/commLink');
			verifyMsg({
				deviceID : appGlobal.deviceID,
				request : 'verifyEmail',
				email : email.value,
			}, verifyEmailCB);

	
	}

	function verifyEmailCB() {
		alert("A verification email has been sent to your email address.   Please click on the verification link in the email to complete the process.");

	}
	
	function animateCB(){
		self.zIndex = 12;
	}

	return self;

}

module.exports = emailEdit;
