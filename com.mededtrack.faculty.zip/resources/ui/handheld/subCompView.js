function subCompView() {

	var selfMod = require('ui/common/backView');

	var self = new selfMod(10, "subCompetencies.png", backFn);

	var contentView = Ti.UI.createView({
		height : '90%',
		top : '10%',
		width : '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dip',
		top : '3%'
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color : 'black'
	});

	var resName = Ti.UI.createLabel({
		font : {
			fontSize : 16
		},
		top : '18dip',
		left : 0,
		color : 'black'
	});

	var msCartButton = Ti.UI.createButton({
		borderColor : 'purple',
		borderRadius : '4',
		borderWidth : '2dip',
		backgroundColor : 'white',
		color : 'purple',
		right : '0',
		top : '0dip',
		height : '40dip',
		width : '40dip',
		font : {
			fontWeight : 'bold'
		}
	});

	resContainer.add(resLabel);
	resContainer.add(resName);
	resContainer.add(msCartButton);

	contentView.add(resContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '77%',
		top : '15%'
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		top : '0dip',
		color : 'black',
		left : 0,
	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		height : '92%',
		top : '30dip',
		borderColor : 'black',
		borderWidth : '2dip'
	});

	viewContainer.add(tableLabel);
	viewContainer.add(tableView);
	contentView.add(viewContainer);
	self.add(contentView);

	Ti.App.addEventListener('resetSubCompView', function() {
		appGlobal.returnTo = 'resetSubCompView';
		Ti.API.info("Reseting SubCompView");
		if (appGlobal.msCart.msAr.length > 0) {
			msCartButton.backgroundColor = 'purple';
			msCartButton.color = 'white';
			msCartButton.enabled = true;
		} else {
			msCartButton.enable = false;
			msCartButton.backgroundColor = 'white';
			msCartButton.color = 'purple';
			msCartButton.borderColor = 'purple';
		}
		if (appGlobal.generalObs) {
			msCartButton.enabled = false;
			msCartButton.opacity = .5;
			msCartButton.color = '#ccc';
			msCartButton.borderColor = '#ccc';
		}
		self.opacity = 1;
		self.zIndex = 20;
		appGlobal.androidBackButton = 'scBackButton';
		msCartButton.title = appGlobal.msCart.msAr.length.toString();
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		tableLabel.text = appGlobal.currentComp.competencyName + " Sub-Competency";
		msCartButton.title = appGlobal.msCart.msAr.length.toString();

		getSubCompsFn();
	});

	Ti.App.addEventListener('scBackButton', function() {
		backFn();
	});

	msCartButton.addEventListener('click', function() {
		if (appGlobal.msCart.msAr.length > 0) {
			self.zIndex = 21;
			Ti.App.fireEvent("resetCartView");
			self.animate({
				duration : 400,
				opacity : 0
			}, animateCB);
		}
	});

	function getSubCompsFn() {
		var getSubComps = require('ui/common/commLink');
		getSubComps({
			request : 'getSubComps',
			idCompetencyTbl : appGlobal.currentComp.idCompetencyTbl,
			idResidentTbl : appGlobal.currentRes.idResidentTbl
		}, getSubCompsCB);
	}

	function getSubCompsCB(jsonReturn) {
		if ( typeof jsonReturn.subCompAr == 'undefined') {
			alert("Unable to communicate with service at this time.  Please try again later.");
			backFn();
			return false;
		}
		appGlobal.subCompAr = jsonReturn.subCompAr;
		Ti.API.info('Sub-Competency Ar = ' + JSON.stringify(appGlobal.subCompAr));

		buildTable();
	}

	function buildTable() {
		tableData = [];
		//tableView.setData(tableData);
		for ( k = 0; k < appGlobal.subCompAr.length; k++) {
			var subcomp = getSub(appGlobal.subCompAr[k].idSubCompTbl);

			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '55dip',
				hasChild : false,
				subcomptbl : subcomp,
				borderColor : appGlobal.colorOne,
				borderWidth : '1dip',
				width: '100%'
			});
			
			var tableGlyph = Ti.UI.createImageView({
				image: '/images/handheld/tableGlyph.png',
				right: '2dp',
				height: '60%',
				width: 'auto'
			});


			var rowView = Ti.UI.createView({
				width : '85%',
				height : '100%',
				zIndex : 1,
				left: '3dp'

			});
			var messageLabel = Ti.UI.createLabel({
				left : 0,
				width : '90%',
				height : '50dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 14
				},
				color : appGlobal.colorOne,
				wordWrap : appGlobal.wordWrap,
				ellipsize : appGlobal.ellipsize,
				text : subcomp.subName
			});

			var scoreLabel = Ti.UI.createLabel({
				right: 0,
				width : '9%',
				height : '50dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 14
				},
				color : appGlobal.colorOne,
				text : appGlobal.subCompAr[k].subCompScore,
				wordWrap : false,
				textAlign: Titanium.UI.TEXT_ALIGNMENT_RIGHT
			});
			rowView.add(messageLabel);
			rowView.add(scoreLabel);
			tableRow.add(tableGlyph);
			tableRow.add(rowView);
			tableData.push(tableRow);
			tableRow.addEventListener('click', function(e) {
				appGlobal.currentSubComp = e.row.subcomptbl;
				self.zIndex = 21;
				if (appGlobal.generalObs) {
					Ti.App.fireEvent('resetObsOnly');
				} else {
					Ti.App.fireEvent("resetMSView");
				}
				self.animate({
					duration : 400,
					opacity : 0
				}, animateCB);
			});

		}
		tableView.setData(tableData);
	}

	function backFn() {
		self.zIndex = 21;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("resetCompView");
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 10;
		//self.opacity = 1;
	}

	function getSub(idSubCompTbl) {
		var db = Ti.Database.open('metDB');
		var subRS = db.execute('SELECT idSubCompTbl, subName, subDescription, idSpecialtyTbl FROM subcomptbl WHERE idSubCompTbl = ?', idSubCompTbl);
		while (subRS.isValidRow()) {
			var subName = subRS.fieldByName('subName');
			var idSubCompTbl = subRS.fieldByName('idSubCompTbl');
			var idSpecialtyTbl = subRS.fieldByName('idSpecialtyTbl');
			var subDescription = subRS.fieldByName('subDescription');
			subRS.next();
		}
		subRS.close();
		var subcomptbl = {
			subName : subName,
			idSubCompTbl : idSubCompTbl,
			idSpecialtyTbl : idSpecialtyTbl,
			subDescription : subDescription
		};
		return subcomptbl;
	}

	return self;

};

module.exports = subCompView;
