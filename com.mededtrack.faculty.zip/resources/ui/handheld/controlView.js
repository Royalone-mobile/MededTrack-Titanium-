function controlView(win) {

	var db;
	var selfMod = require('ui/common/standardView');

	var rowClickOn = true;

	var menuIcon = Ti.UI.createImageView({
		image : '/images/handheld/menuIcon.png',
		height : Ti.UI.SIZE,
		left : '1%',
		width : '6%'
	});

	var self = new selfMod(9, menuIcon);

	menuIcon.addEventListener('click', showMenu);

	var titleView = Ti.UI.createView({
		width : '100%',
		height : '60dip',
		top : '12%'
	});

	var orgLabel = Ti.UI.createLabel({
		width : '100%',
		font : {
			fontSize : 16,
			fontWeight : 'bold'
		},
		textAlignment : 'left',
		text : appGlobal.licensetbl.orgName + " Residents",
		top : '0',
		left : '7%',
		color : 'black'
	});

	orgLabel.addEventListener("click", function() {
		Ti.App.fireEvent('resetUpdate');
		self.zIndex = 9;
		self.opacity = 0;
	});

	titleView.add(orgLabel);

	var resPickerView = Ti.UI.createView({
		width : '86%',
		height : '72%',
		top : '19%'
	});

	var searchbar = Ti.UI.createSearchBar({
		barColor : '#385292',
		showCancel : false
	});

	var resIndex = [];

	var resData = [];

	var resTable = Ti.UI.createTableView({
		borderColor : 'black',
		borderWidth : '2dip',
		width : '100%',
		height : '93%',
		top: 0
	});
	
	var resAdvice = Ti.UI.createLabel({
		text: 'Tap name for observation. Long-press for resident data.',
		bottom: 0,
		font : {
			fontWeight : 'bold',
			fontSize : 12
		},
		color : 'black'
	});

	/*
	if (Ti.Platform.name === 'iOS') {
		resTable.search = searchbar;
		resTable.searchHidden = true;
	}
	*/

	var adviceView = Ti.UI.createView({
		borderColor : appGlobal.colorOne,
		borderWidth : '1dip',
		borderRadius : 4,
		height : '35%',
		width : '65%',
		backgroundColor : 'white',
		visible : false,
	});

	var adviceMsg = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 16
		},
		color : '#555',
	});

	adviceView.add(adviceMsg);

	resPickerView.add(resTable);
	resPickerView.add(resAdvice);
	self.add(titleView);
	self.add(resPickerView);
	self.add(adviceView);

	Ti.App.addEventListener('restartControlView', restartControl);

	resTable.addEventListener('indexclick', function(e) {
		Ti.API.info("Index Click = " + JSON.stringify(e));
		resTable.scrollToIndex(e.index);
	});

	Ti.App.addEventListener("showAdvice", function(e) {
		restartControl();
		adviceMsg.text = e.data;
		adviceView.opacity = 1;
		adviceView.visible = true;
		setTimeout(function() {
			adviceView.animate({
				duration : 1800,
				opacity : 0
			}, endAdviceCB);
		}, 1300);

	});
	
	Ti.App.addEventListener('controlBackButton', function() {
		win.close();
	});

	function restartControl() {
		self.opacity = 1;
		self.zIndex = 20;
		rowClickOn = true;
		appGlobal.form = {};
		appGlobal.generalObs = false;
		orgLabel.text = appGlobal.licensetbl.orgName + " Residents";
		resIndex = [];
		resData = [];
		fillTable();
		appGlobal.androidBackButton = 'controlBackButton';
	}

	function endAdviceCB() {
		adviceView.visible = false;
		adviceView.opacity = 0;
	};

	return self;

	function fillTable() {
		resTableData = [];
		 var getRes = require('ui/common/commLink');
		 getRes({
		 request : 'getDBChange',
		 deviceID : appGlobal.idDeviceID,
		 idLicenseTbl : appGlobal.licensetbl.idLicenseTbl
		 }, fillTableCB);
		
	}
	
	function fillTableCB(jsonReturn){
		if ( typeof jsonReturn == undefined || jsonReturn.lastChange == undefined) {
			alert("Unable retrieve current information.  Check connectivity and try again.");
			Ti.App.fireEvent('restartControlView');
			return false;
		}
		if (jsonReturn.errorMsg) {
			alert("Error Message" + errorMsg);
			Ti.App.fireEvent('restartControlView');
			return false;
		}
		appGlobal.lastChange = jsonReturn.lastChange;
		appGlobal.lastSynch = Ti.App.Properties.getString('lastSynch');
		if (appGlobal.lastSynch < appGlobal.lastChange || appGlobal.lastSynch == null || appGlobal.prevAppVersion < appGlobal.appVersion) {
			Ti.App.fireEvent('resetUpdate');
		} else {
			buildTable();
		}
	}

	function buildTable() {

		var aIdx = '';
		var i = 0;
		var db = Ti.Database.open('metDB');
		var resRS = db.execute('SELECT idResidentTbl, lastName, firstName, specialtyName, idSpecialtyTbl, email, mobilePhone FROM residenttbl ORDER BY lastName, firstName');
		while (resRS.isValidRow()) {
			var lastName = resRS.fieldByName('lastName');
			var firstName = resRS.fieldByName('firstName');
			var idResidentTbl = resRS.fieldByName('idResidentTbl');
			var specialtyName = resRS.fieldByName('specialtyName');
			var idSpecialtyTbl = resRS.fieldByName('idSpecialtyTbl');
			var email = resRS.fieldByName('email');
			var mobilePhone = resRS.fieldByName('mobilePhone');
			
			if (aIdx != lastName.substring(0, 1)) {
				aIdx = lastName.substring(0, 1);
				resIndex.push({
					title : aIdx,
					index : i
				});
			}
			var rowView = Ti.UI.createTableViewRow({
				height : '55dip',
				width : '100%',
				currentRes: {idResidentTbl: idResidentTbl, lastName: lastName, firstName: firstName, specialtyName: specialtyName, idSpecialtyTbl: idSpecialtyTbl, email: email, mobilePhone: mobilePhone },
			});
			var rowLabel = Ti.UI.createLabel({
				text : lastName + ', ' + firstName,
				left : '3dip',
				width : '100%',
				height : '50dip',
				font : {
					fontWeight : 'Bold',
					fontSize : 16
				},
				color : appGlobal.colorOne,
				wordWrap : appGlobal.wordWrap,
				ellipsize : appGlobal.ellipsize,
			});
			rowView.add(rowLabel);
			resData.push(rowView);
			rowView.addEventListener('click', function(e) {
				//Ti.API.info(JSON.stringify(e));
				Ti.API.info("Start Click");
				if (rowClickOn) {
					appGlobal.currentRes = e.row.currentRes;
					self.zIndex = 21;
					Ti.App.fireEvent("resetCompView");
					self.animate({
						duration : 400,
						opacity : 0
					}, animationCB);
				}

			});
			rowView.addEventListener('longpress', function(e) {
				rowClickOn = false;
				appGlobal.currentRes = e.row.currentRes;
				self.zIndex = 30;
				Ti.App.fireEvent('resetResidentView');
				self.animate({
					duration : 500,
					opacity : 0
				}, animationCB);
			});
			i++;
			resRS.next();
		}
		resRS.close();
		if (Ti.Platform.name == 'iOS') {
			resTable.setIndex(resIndex);
		}
		resTable.setData(resData);
		db.close();
	}

	function animationCB() {
		self.zIndex = 11;
		//self.opacity = 1;
	}

	function showMenu() {

		if (!appGlobal.settingsShown) {
			Ti.App.fireEvent('resetSettings');
			appGlobal.settingsShown = true;
			self.animate({
				left : '87%',
				duration : 400,
				opacity : .5
			}, animateCB);

		} else {
			appGlobal.settingsShown = false;
			self.animate({
				left : 0,
				duration : 400,
				opacity : 1
			}, animateCB);
			Ti.App.fireEvent('closeSettings');

		}

		//Ti.App.fireEvent('buildSettingsTable');
	}

	function animateCB() {
		/*
		 if (appGlobal.settingsShown){
		 self.zIndex = 19;
		 } else {
		 self.zIndex = 20;
		 }
		 */
	}

}

module.exports = controlView;
