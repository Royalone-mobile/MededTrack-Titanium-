function licenseView() {

	var selfMod = require('ui/common/standardView');

	var self = new selfMod(1);

	var updateOn = false;

	var licView = Ti.UI.createView({
		width : '100%',
		height : '100%',
		top : '75dip',
	});

	var licNumberLabel = Ti.UI.createLabel({
		text : 'Your License Number',
		font : {
			fontSize : 18,
			fontWeight : 'bold'
		},
		left : '10%',
		top : '50dip',
		color: 'black'
	});

	var licenseNumber = Ti.UI.createTextField({
		width : '80%',
		left : '10%',
		height : '45dp',
		hintText : 'License Number',
		keyboardType : Ti.UI.KEYBOARD_TYPE_ASCIIEYBOARD_ASCII,
		top : '75dip',
		borderWidth : '2dp',
		borderColor : 'gray',
		borderRadius : 6,
		paddingLeft : '6dp',
		color : 'black',
		returnKeyType: Titanium.UI.RETURNKEY_DONE,
		value : appGlobal.licenseNumber,
		editable: false
	});

	if (Ti.Platform.name != 'android') {
		licenseNumber.clearButtonMode = Titanium.UI.INPUT_BUTTONMODE_ALWAYS;
	}

	var validateButton = Ti.UI.createButton({
		width : '60%',
		height : '45dip',
		title : "Validate",
		color : 'white',
		backgroundColor : '#ccc',
		borderRadius : 6,
		bottom : '20%',
		font : {
			fontWeight : 'bold'
		},
		enabled : false
	});

	licView.add(licNumberLabel);
	licView.add(licenseNumber);
	licView.add(validateButton);

	self.add(licView);

	licenseNumber.addEventListener('change', function() {
		var p = licenseNumber.value.trim();
		if (p.length >= 12) {
			validateButton.enabled = true;
			validateButton.backgroundColor = appGlobal.colorOne;
		} else {
			validateButton.enabled = false;
			validateButton.backgroundColor = '#ccc';
		}
	});

	validateButton.addEventListener('click', function() {
		licenseNumber.blur();
		if (Ti.Platform.name == 'android') {
			Ti.UI.Android.hideSoftKeyboard();
		}
		Ti.API.info("Validate Button Pressed");
		Ti.App.Properties.setString('licenseNumber', '');
		Ti.App.Properties.setString('token', '');
		Ti.App.Properties.setString('sid', '');
		var licCheck = require('ui/common/commLink');
		licCheck({
			request : 'licCheck',
			licenseNumber : licenseNumber.value,
			deviceID : appGlobal.deviceID,
			idOrgTbl : appGlobal.idOrgTbl
		}, validateCB);
	});

	Ti.App.addEventListener('licenseCheck', function() {
		self.zIndex = 31;
		self.opacity = 1;
		self.visible = true;
		licenseNumber.editable = true;
		licenseNumber.focus();
		licenseNumber.value = appGlobal.licensetbl.licenseNumber;

		var p = String(licenseNumber.value).trim();
		Ti.API.info("licView has focus");
		if (p.length >= 12) {
			validateButton.enabled = true;
			validateButton.backgroundColor = appGlobal.colorOne;
		} else {
			validateButton.backgroundColor = "#ccc";
			validateButton.enabled = false;
		}

	});
	
	Ti.App.addEventListener('hideLicenseView', function() {
		self.zIndex = 1;
		self.opacity = 0;
		self.visible = false;

	});


	function validateCB(jsonReturn) {
		if ( typeof jsonReturn.licensetbl == 'undefined') {
			alert("Unable to get license information at this time.  Please try again.");
			return false;
		}
		if (jsonReturn.licensetbl.errorMsg) {
			alert(jsonReturn.licensetbl.errorMsg);
			licenseNumber.focus();
			return false;
		}

		Ti.API.info("Lic Info = " + JSON.stringify(jsonReturn.licensetbl));

		Ti.App.Properties.setString('licenseNumber', jsonReturn.licensetbl.licenseNumber);
		Ti.App.Properties.setString('sid', jsonReturn.licensetbl.licenseSid);
		Ti.App.Properties.setString('token', jsonReturn.licensetbl.licenseToken);

		appGlobal.licensetbl = jsonReturn.licensetbl;
		appGlobal.specAr = jsonReturn.specAr;
		appGlobal.idOrgTbl = appGlobal.licensetbl.idOrgTbl;

		Ti.API.info(JSON.stringify(appGlobal.specAr));

		Ti.App.fireEvent('restartControlView');
		self.animate({
			duration : 800,
			opacity : 0
		}, animateDB);

	}

	function animateDB() {
		self.zIndex = 1;
		self.opacity = 1;
	}

	return self;

};

module.exports = licenseView;
