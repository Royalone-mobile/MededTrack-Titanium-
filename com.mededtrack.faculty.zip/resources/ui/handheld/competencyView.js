function competencyView() {

	var selfMod = require('ui/common/backView');

	var searchIcon = Ti.UI.createImageView({
		image : '/images/handheld/searchIcon.png',
		height : '70%',
		width : Ti.UI.SIZE,
		right : '1%',
		zIndex : 4
	});

	var self = new selfMod(10, "compentencies.png", backFn, searchIcon);

	var searchShield = Ti.UI.createView({
		opacity : .5,
		backgroundColor : '#ccc',
		height : '100%',
		width : '100%',
		zIndex : 9,
		visible : false
	});

	var searchBox = Ti.UI.createView({
		width : '90%',
		height : '30%',
		borderColor : '#777777',
		borderRadius : 6,
		borderWidth : '2dp',
		backgroundColor : 'white',
		zIndex : 10,
		top : '15%',
		visible : false
	});

	var searchLabel = Ti.UI.createLabel({
		text : 'Milestone Search',
		top : '5dp',
		color : '#5A5B5B',
	});

	var searchText = Ti.UI.createTextField({
		width : '90%',
		height : '45dp',
		backgroundColor : '#eeeeee',
		hintText : 'Search Text',
		color: 'black'
	});

	var searchButton = Ti.UI.createButton({
		height : '45dp',
		right : '5dp',
		width : '45%',
		title : 'Search',
		bottom : '5dp',
		color : '#ccc',
		enabled : false,
		backgroundColor: 'white'
	});

	var cancelButton = Ti.UI.createButton({
		height : '45dp',
		left : '5dp',
		width : '45%',
		title : 'Cancel',
		color : 'blue',
		bottom : '5dp',
		backgroundColor: 'white'
	});

	searchBox.add(searchLabel);
	searchBox.add(searchText);
	searchBox.add(searchButton);
	searchBox.add(cancelButton);

	var contentView = Ti.UI.createView({
		height : '90%',
		top : '10%',
		width : '100%'
	});

	var resContainer = Ti.UI.createView({
		width : '85%',
		height : '50dp',
		top : '3%'
	});

	var resLabel = Ti.UI.createLabel({
		text : 'Resident',
		font : {
			fontWeight : 'bold',
			fontSize : 12,
		},
		left : 0,
		top : 0,
		color : 'black'
	});

	var resName = Ti.UI.createLabel({
		font : {
			fontSize : 16
		},
		top : '18dp',
		left : 0,
		color : 'black'
	});

	var msCartButton = Ti.UI.createButton({
		borderColor : 'purple',
		borderRadius : '4',
		borderWidth : '2dp',
		backgroundColor : 'white',
		color : 'purple',
		right : '0',
		top : '0dp',
		height : '40dp',
		width : '40dp',
		font : {
			fontWeight : 'bold'
		}
	});

	resContainer.add(resLabel);
	resContainer.add(resName);
	resContainer.add(msCartButton);

	contentView.add(resContainer);

	var viewContainer = Ti.UI.createView({
		width : '85%',
		height : '75%',
		top : '15%'
	});

	var tableLabel = Ti.UI.createLabel({
		font : {
			fontWeight : 'bold',
			fontSize : 12,
			fontColor : 'black'
		},
		top : '0dp',
		color : 'black',
		left : 0,

	});

	var tableView = Ti.UI.createTableView({
		width : '100%',
		height : '90%',
		top : '18dp',
		borderColor : 'black',
		borderWidth : '2dp'
	});

	var generalObsView = Ti.UI.createView({
		width : '85%',
		height : '40dip',
		bottom : '25dip',
		borderRadius : 5,
		borderWidth : '2dp',
		borderColor : 'white',
		backgroundColor : '#ccc',
	});

	var generalObsLabel = Ti.UI.createLabel({
		color : 'white',
		text : "General Observation",
		left : '5dp',
		font : {
			fontSize : 16
		}
	});

	var generalObsSwitch = Ti.UI.createSwitch({
		right : '5dp',
		value : true,
		enabled : true,
		zIndex : 30
	});

	generalObsView.add(generalObsLabel);
	generalObsView.add(generalObsSwitch);

	viewContainer.add(tableLabel);
	viewContainer.add(tableView);

	contentView.add(viewContainer);
	contentView.add(generalObsView);

	searchIcon.addEventListener('click', function() {
		Ti.API.info("Click on Search Icon");
		searchText.value = '';
		searchButton.color = '#ccc';
		searchButton.enabled = false;
		searchBox.visible = true;
		
		searchShield.opacity = 0;
		searchShield.visible = true;
		searchShield.animate({
			duration : 400,
			opacity : .5
		});
		searchText.focus();
	});

	cancelButton.addEventListener("click", function() {
		searchText.blur();
		searchBox.visible = false;
		searchShield.visible = false;
	});

	searchText.addEventListener('change', function() {
		if (searchText.value) {
			searchButton.enabled = true;
			searchButton.color = 'blue';
		} else {
			searchButton.enabled = false;
			searchButton.color = '#ccc';
		}
	});

	searchButton.addEventListener("click", function() {
		searchText.blur();
		searchText.value = searchText.value.trim();
		var searchTerm = '%' + searchText.value + '%';
		var db = Ti.Database.open('metDB');
		var msRS = db.execute("SELECT count(*) as 'count' FROM milestonetbl WHERE msName LIKE '" + searchTerm + "' OR msDescription LIKE '" + searchTerm + "'");
		var count = msRS.fieldByName('count');
		Ti.API.info("Matching Rows = "+count);
		searchBox.visible = false;
		searchShield.visible = false;
		self.zIndex = 21;
		if (count > 0 && searchText.value) {
			Ti.App.fireEvent("resetMSSearch", {
				searchValue : searchText.value
			});
			self.animate({
				duration : 400,
				opacity : 0
			}, animateCB);
		} else {
			alert("No results");
		}
		
	});

	//self.add(searchIcon);
	self.add(searchBox);
	self.add(contentView);
	self.add(searchShield);

	generalObsView.addEventListener('click', function() {
		if (appGlobal.msCart.msAr.length == 0) {
			if (generalObsSwitch.value) {
				generalObsSwitch.value = false;
				searchIcon.visible = true;
			} else {
				generalObsSwitch.value = true;
				searchIcon.visible = false;
			}
		} else {
			alert("You must either clear or record current milestone observations, before recording a general observation.");
		}

	});

	generalObsSwitch.addEventListener("change", function() {
		if (generalObsSwitch.value == true) {
			appGlobal.generalObs = true;
			searchIcon.visible = false;
			generalObsView.backgroundColor = 'white';
			generalObsView.borderColor = '#ccc';
			generalObsLabel.color = appGlobal.colorOne;
			msCartButton.enabled = false;
			msCartButton.color = '#ccc';
			msCartButton.borderColor = '#ccc';
			msCartButton.opacity = .5;
		} else {
			appGlobal.generalObs = false;
			searchIcon.visible = true;
			generalObsView.backgroundColor = '#ccc';
			generalObsView.borderColor = 'white';
			generalObsLabel.color = 'white';
			msCartButton.enabled = true;
			msCartButton.color = 'purple';
			msCartButton.borderColor = 'purple';
			msCartButton.opacity = 1;
		}
	});

	msCartButton.addEventListener('click', function() {
		if (appGlobal.msCart.msAr.length > 0) {
			self.zIndex = 21;
			Ti.App.fireEvent("resetCartView");
			self.animate({
				duration : 400,
				opacity : 0
			}, animateCB);
		}
	});

	Ti.App.addEventListener('resetCompView', function() {
		appGlobal.returnTo = 'resetCompView';
		Ti.API.info("Start Reset Comp View");
		if (appGlobal.msCart.msAr.length) {
			msCartButton.backgroundColor = 'purple';
			msCartButton.color = 'white';
			msCartButton.enabled = true;
			generalObsView.enabled = false;
			generalObsSwitch.enabled = false;
		} else {
			msCartButton.enable = false;
			msCartButton.backgroundColor = 'white';
			msCartButton.color = 'purple';
			generalObsView.enabled = true;
			generalObsSwitch.enabled = true;
		}
		if (appGlobal.generalObs) {
			generalObsSwitch.value = true;
			generalObsView.backgroundColor = 'white';
			generalObsView.borderColor = '#ccc';
			generalObsLabel.color = appGlobal.colorOne;
			msCartButton.enabled = false;
			msCartButton.color = '#ccc';
			msCartButton.borderColor = '#ccc';
			msCartButton.opacity = .5;
		} else {
			generalObsSwitch.value = false;
			generalObsView.backgroundColor = '#ccc';
			generalObsView.borderColor = 'white';
			generalObsLabel.color = 'white';
		}
		self.opacity = 1;
		self.zIndex = 20;

		appGlobal.androidBackButton = 'compBackButton';
		msCartButton.title = appGlobal.msCart.msAr.length.toString();
		resName.text = appGlobal.currentRes.firstName + ' ' + appGlobal.currentRes.lastName;
		tableLabel.text = appGlobal.currentRes.specialtyName + " Competency";
		if (appGlobal.msCart.msAr.length) {
			msCartButton.backgroundColor = 'purple';
			msCartButton.color = 'white';
			msCartButton.enabled = true;
			generalObsView.enabled = false;
			generalObsSwitch.enabled = false;
		} else {
			msCartButton.enable = false;
			msCartButton.backgroundColor = 'white';
			msCartButton.color = 'purple';
			generalObsView.enabled = true;
			generalObsSwitch.enabled = true;
		}
		//getCompetenciesFn();
		Ti.API.info("Building Comp Table");
		buildTable();
	});

	Ti.App.addEventListener('compBackButton', function() {
		backFn();
	});

	function buildTable() {
		var k = 0;
		tableData = [];
		//tableView.setData(tableData);
		var db = Ti.Database.open('metDB');
		var compRS = db.execute('SELECT idCompetencyTbl, competencyName, idSpecialtyTbl FROM competencytbl ORDER BY displayOrder');
		while (compRS.isValidRow()) {
			var competencyName = compRS.fieldByName('competencyName');
			var idCompetencyTbl = compRS.fieldByName('idCompetencyTbl');
			var idSpecialtyTbl = compRS.fieldByName('idSpecialtyTbl');

			var tableRow = Ti.UI.createTableViewRow({
				backgroundColor : 'white',
				touchEnabled : true,
				height : '55dp',
				hasChild : false,
				indexVal : k,
				competencytbl : {
					idCompetencyTbl : idCompetencyTbl,
					competencyName : competencyName,
					idSpecialtyTbl : idSpecialtyTbl
				},
				borderColor : '#ccc',
				borderWidth : '1dp',
				width: '100%'
			});

			var tableGlyph = Ti.UI.createImageView({
				image : '/images/handheld/tableGlyph.png',
				right : '2dp',
				height : '60%',
				width : 'auto'
			});

			var rowView = Ti.UI.createView({
				width : '95%',
				height : '100%',
				left: '3dp',
				zIndex : 1,
				indexVal : k,

			});
			var messageLabel = Ti.UI.createLabel({
				left : '0',
				width : '96%',
				height : '50dp',
				font : {
					fontWeight : 'Bold',
					fontSize : 14
				},
				color : appGlobal.colorOne,
				wordWrap : appGlobal.wordWrap,
				ellipsize : appGlobal.ellipsize,
				indexVal : k,
				text : competencyName
			});

			rowView.add(messageLabel);
			tableRow.add(rowView);
			tableRow.add(tableGlyph);
			tableData.push(tableRow);
			tableRow.addEventListener('click', function(e) {
				appGlobal.currentComp = e.row.competencytbl;
				self.zIndex = 21;
				Ti.App.fireEvent('resetSubCompView');
				self.animate({
					duration : 400,
					opacity : 0
				}, animateCB);
			});
			k++;
			compRS.next();
		}
		tableView.setData(tableData);
		compRS.close();
	}

	function backFn() {
		self.zIndex = 21;
		searchBox.visible = false;
		searchShield.visible = false;
		appGlobal.androidBackButton = null;
		Ti.App.fireEvent("restartControlView");
		appGlobal.msCart.msAr = [];
		appGlobal.msCart.filed = true;
		appGlobal.msCart.observation = '';
		self.animate({
			duration : 400,
			opacity : 0
		}, animateCB);
	}

	function animateCB() {
		self.zIndex = 10;
		//self.opacity = 1;
	}

	return self;

};

module.exports = competencyView;
