function blankView() {

	var self = Ti.UI.createView({
		height : '100%',
		width : Ti.Platform.displayCaps.platformWidth,  // Used to be 100%
		backgroundColor : 'white',
		zIndex : 18
	});
	
	self.addEventListener('click',function(){
		Ti.API.info("click");
	});
	
	return self;

};

module.exports = blankView;
