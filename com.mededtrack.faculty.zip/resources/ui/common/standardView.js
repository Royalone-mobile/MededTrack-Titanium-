function standardView(zIdx, menuIcon) {

	var self = Ti.UI.createView({
		height : '100%',
		width : '100%', 
		backgroundColor : 'white',
		zIndex : zIdx
	});
	
	var headerView = Ti.UI.createView({
		backgroundColor : '#ffffff',
		top : 0,
		height : '70dp',
		width : '100%',
	});
	
	var logoBar = Ti.UI.createView({
		height: '100%',
		//bottom: '5%'
	});

	var logo = Ti.UI.createImageView({
		image : '/images/handheld/mainHeaderBar.png',
		//width : '85%',
		height : Ti.UI.SIZE,
		//bottom: '5%'
	});
	
	logoBar.add(logo);
	
	if (menuIcon){
		logoBar.add(menuIcon);
	}
	
	headerView.add(logoBar);
	
	var copywriteText = Ti.UI.createLabel({
		font : {
			fontSize : 10
		},
		bottom : '5dip',
		color : 'black',
		text : appGlobal.handHeldCopyrightText
	});
	

	var versionLabel = Ti.UI.createLabel({
		font : {
			fontSize : 10
		},
		bottom : '5dip',
		left : '5dip',
		color : 'black',
		text : "V " + appGlobal.appVersion
	});

	self.add(headerView);
	self.add(versionLabel);
	self.add(copywriteText);

	return self;

}

module.exports = standardView;
