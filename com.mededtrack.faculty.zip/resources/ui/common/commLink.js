//============================================================+
// File name     : commLink.js
// Begin           : Monday; October 7, 2013, 8:52 AM
// Last Update  : Monday; October 7, 2013
//
// Description : Common HTTP Client
//
//
// Author: Marc Schneider
//
// (c) Copyright: October 7, 2013
//                      Aultman Health Foundation and
//                      Marc Schneider
//                      Avondale Labs
//                      Canton OH
//============================================================+

function commLink(params, callback) {
	params.deviceID = appGlobal.deviceID;
	var xhr = Titanium.Network.createHTTPClient({
		onload : function(e) {
			var jsonReturn = JSON.parse(this.responseText);
			if (jsonReturn.securityMsg != undefined){
				alert(jsonReturn.securityMsg);
			} else callback(jsonReturn);
		},
		onerror : function(e) {
			Ti.API.debug(e.error);
			callback(JSON.stringify({
				errorMsg : "Error " + e.error
			}));
		},
		timeout : 8000 // in milliseconds
	});

	xhr.open("POST", appGlobal.srvcEndPt);
	xhr.send(JSON.stringify(params));
}

module.exports = commLink;
